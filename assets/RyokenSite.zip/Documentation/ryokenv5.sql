-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 25 fév. 2021 à 12:13
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ryokenv5`
--

-- --------------------------------------------------------

--
-- Structure de la table `adherent`
--

DROP TABLE IF EXISTS `adherent`;
CREATE TABLE IF NOT EXISTS `adherent` (
  `ID_PSEUDO` char(32) NOT NULL,
  `STATUT` char(32) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `IMAGE` text,
  `TWITTER` varchar(128) DEFAULT NULL,
  `AGE` int(2) DEFAULT NULL,
  `NOM` char(32) DEFAULT NULL,
  `PRENOM` char(32) DEFAULT NULL,
  `MDP` char(32) DEFAULT NULL,
  `ROLE` char(255) DEFAULT NULL,
  PRIMARY KEY (`ID_PSEUDO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `adherent`
--

INSERT INTO `adherent` (`ID_PSEUDO`, `STATUT`, `DESCRIPTION`, `IMAGE`, `TWITTER`, `AGE`, `NOM`, `PRENOM`, `MDP`, `ROLE`) VALUES
('Torior', 'Admin', 'AZEDAZDAED', './img/gaming-in-computer-club-Y55RPUN.jpg', 'ZAEDZAEDZAED', 15, 'ZAEDAZEDAZ', 'EDAZEDAZEDZEAD', 'ccace46bc8b06a8e5a7e979f31da66b2', 'DAZDA'),
('', 'Utilisateur', 'dzdzdzdzdz', '', 'dzdzdz', 15, 'dzzdzdzd', 'dzdzdzdz', 'cscsef', 'dzdzd');

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `NOM_ARTICLES` char(32) NOT NULL,
  `LIBELLE_CATEGORIE` char(32) NOT NULL,
  `description` text NOT NULL,
  `NOM_PARTENAIRE` char(32) NOT NULL,
  `PRIXORIGINE` double(5,2) DEFAULT NULL,
  `PRIXVENTEUNITAIRE` double(5,2) DEFAULT NULL,
  `img_article` text NOT NULL,
  PRIMARY KEY (`NOM_ARTICLES`),
  KEY `I_FK_ARTICLES_CATEGORIES` (`LIBELLE_CATEGORIE`),
  KEY `I_FK_ARTICLES_PARTENAIRES` (`NOM_PARTENAIRE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `articles`
--

INSERT INTO `articles` (`NOM_ARTICLES`, `LIBELLE_CATEGORIE`, `description`, `NOM_PARTENAIRE`, `PRIXORIGINE`, `PRIXVENTEUNITAIRE`, `img_article`) VALUES
('ryoken sweat', 'SWEATS', 'ryoken sweats ryoken sweats ryoken sweats ryoken sweats ryoken sweats ryoken sweats ryoken sweats ryoken sweats ryoken sweats ', 'ryoken sweats', 1.00, 4.00, 'img/6036db193d5a98.56112439.jpg'),
('ryoken pantalon', 'PANTLONS', 'ryoken pantalon ryoken pantalon ryoken pantalon', 'ryoken pantalon', 5.00, 10.00, 'img/6036da98731978.23550821.jpg'),
('ryoken stickers', 'STICKERS', 'ryoken stickers ryoken stickers ryoken stickers ryoken stickers ryoken stickers ', 'ryoken stickers', 3.00, 6.00, 'img/6036dac8534fc7.53458380.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `LIBELLE_CATEGORIE` char(32) NOT NULL,
  `FAMILLE_CATEGORIE` char(32) DEFAULT NULL,
  PRIMARY KEY (`LIBELLE_CATEGORIE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`LIBELLE_CATEGORIE`, `FAMILLE_CATEGORIE`) VALUES
('SWEATS', 'vêtements'),
('PANTLONS', 'vêtements'),
('STICKERS', 'accessoires');

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `ID_PSEUDO` char(32) NOT NULL,
  `PAYS` char(32) DEFAULT NULL,
  `EMAIL` varchar(128) DEFAULT NULL,
  `ADRESSE` varchar(128) DEFAULT NULL,
  `AGE` int(2) DEFAULT NULL,
  `NOM` char(32) DEFAULT NULL,
  `PRENOM` char(32) DEFAULT NULL,
  `MDP` char(32) DEFAULT NULL,
  PRIMARY KEY (`ID_PSEUDO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`ID_PSEUDO`, `PAYS`, `EMAIL`, `ADRESSE`, `AGE`, `NOM`, `PRENOM`, `MDP`) VALUES
('cscscscs', NULL, NULL, NULL, NULL, 'cscscs', 'cscscs', 'c071bd38e4c31ed73ec02faa32b52e4a'),
('FEZFZEFEZF', NULL, NULL, NULL, NULL, 'FZEFZEF', 'ZFEEZFEZ', 'be0b0ddf73060d78bcf5567789520432'),
('meedlaaah', 'qsdfqsd', 'qqsdfqsfd', 'fqsdfqfdqf', 17, 'zebi', 'lahceen', 'ccace46bc8b06a8e5a7e979f31da66b2'),
('marceel', NULL, NULL, NULL, NULL, 'ZEBI', 'ZEBI', 'ccace46bc8b06a8e5a7e979f31da66b2'),
('SelSel', NULL, NULL, NULL, NULL, 'nowakowski', 'marcel', 'ccace46bc8b06a8e5a7e979f31da66b2'),
('mouhouhouhohuomed', 'France', 'marcel.1999@live.fr', '320 avenue pierre ', 21, 'Marcel', 'Nowakowski', 'ccace46bc8b06a8e5a7e979f31da66b2'),
('kujhygtfrdes', NULL, NULL, NULL, NULL, 'nhbgvfd', 'hnbgvfd', '644ea90e77f36cce177b53fe3bd42d57'),
('hfrghfhsdh', NULL, NULL, NULL, NULL, 'sfergfggefr', 'dfggfbfggdg', '29ac6c397589c46cc371b8bbc1f311c9'),
('jnhb', NULL, NULL, NULL, NULL, 'uyjhtgrf', 'uyhtrgf', '5eee34f9fe9d31335a4bd101b8bf66e4'),
('FEVZERjhgjfhkfgk', NULL, NULL, NULL, NULL, 'gfdsqgsdfqsdfqs', 'dfqsdfqsdfsdfqsdfqsdfqsdf', '24a2f6d124e089cb16a5135714e9df02'),
('lkjhgfds', NULL, NULL, NULL, NULL, 'loiuhyb', 'mlokjhgf', 'e3d5cdad69a04750895706ef3d904e78'),
('lkijhgf', NULL, NULL, NULL, NULL, 'Marcel', 'Nowakowski', '15576058df5bdd5e4659db55e7b7182c'),
('marceelrre', 'maroc', '', NULL, 15, 'Lahcen', 'Mohamed', 'f1b97b4b9c482791852eb7d6012ea327'),
('marceelEEEem', 'maroc', 'meedlaah@gmail.com', NULL, 15, 'Lahcen', 'Mohamed', 'f1b97b4b9c482791852eb7d6012ea327'),
('marceltest', 'Maroc', 'meedlaah@gmail.com', NULL, 15, 'lahcen', 'mohamed', '6206b3e1027f382c3f0bf400f8e50a8c');

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

DROP TABLE IF EXISTS `commande`;
CREATE TABLE IF NOT EXISTS `commande` (
  `ID_COMMANDE` bigint(4) NOT NULL AUTO_INCREMENT,
  `ID_PSEUDO` char(32) NOT NULL,
  `ADRESSELIVRAISON` varchar(255) DEFAULT NULL,
  `NOM_PRENOM_LIVRAISON` varchar(255) NOT NULL,
  `DATE_COMMANDE` timestamp NULL DEFAULT NULL,
  `NUMERO_PORTABLE` varchar(255) NOT NULL,
  PRIMARY KEY (`ID_COMMANDE`),
  KEY `I_FK_COMMANDE_CLIENTS` (`ID_PSEUDO`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`ID_COMMANDE`, `ID_PSEUDO`, `ADRESSELIVRAISON`, `NOM_PRENOM_LIVRAISON`, `DATE_COMMANDE`, `NUMERO_PORTABLE`) VALUES
(1, 'Torior', 'zaefzeafazefaq', 'ezfdzef', '2021-02-08 09:06:03', 'azefzefzaef'),
(2, 'Torior', 'azefazef', 'fazefeazf', '2021-02-08 09:06:54', 'azefazfzaef'),
(3, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 09:07:09', '06292929292'),
(4, 'Torior', 'lol', 'mohamed', '2021-02-08 09:07:16', 'lahcen'),
(5, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 09:08:14', '06292929292'),
(6, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 09:09:46', '06292929292'),
(7, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 09:10:04', '06292929292'),
(8, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 09:10:13', '06292929292'),
(9, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 09:10:21', '06292929292'),
(10, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 09:17:43', '06292929292'),
(11, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 09:21:58', '06292929292'),
(12, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 09:27:34', '06292929292'),
(13, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 09:35:01', '06292929292'),
(14, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 09:35:12', '06292929292'),
(15, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 09:43:10', '06292929292'),
(16, 'Torior', 'erferf', 'frefe', '2021-02-08 09:43:57', 'rfzrferf'),
(17, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 09:46:39', '06292929292'),
(18, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 09:48:25', '06292929292'),
(19, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 09:49:11', '06292929292'),
(20, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 10:14:15', '06292929292'),
(21, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 10:20:58', '06292929292'),
(22, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 10:21:28', '06292929292'),
(23, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 10:24:14', '06292929292'),
(24, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-08 10:24:35', '06292929292'),
(25, 'Torior', 'dzdzzdzdzd', 'nowakowski', '2021-02-08 10:25:27', 'dzdz'),
(26, 'Torior', 'dzdzzdzdzd', 'nowakowski', '2021-02-08 10:28:04', 'dzdz'),
(27, 'Torior', 'dzdzzdzdzd', 'nowakowski', '2021-02-08 10:50:40', 'dzdz'),
(28, 'Torior', 'dzdzzdzdzd', 'nowakowski', '2021-02-08 10:51:47', 'dzdz'),
(29, 'Torior', 'dzdzzdzdzd', 'nowakowski', '2021-02-08 11:07:10', 'dzdz'),
(30, 'Torior', 'dzdzzdzdzd', 'nowakowski', '2021-02-08 11:08:28', 'dzdz'),
(31, 'Torior', 'dzdzzdzdzd', 'nowakowski', '2021-02-08 12:02:45', 'dzdz'),
(32, 'Torior', 'dzdzzdzdzd', 'nowakowski', '2021-02-08 12:11:04', 'dzdz'),
(33, 'Torior', 'dzdzzdzdzd', 'nowakowski', '2021-02-08 12:11:35', 'dzdz'),
(34, 'Torior', 'dzdzzdzdzd', 'nowakowski', '2021-02-08 12:11:40', 'dzdz'),
(35, 'Torior', 'dzdzzdzdzd', 'nowakowski', '2021-02-08 12:11:43', 'dzdz'),
(36, 'Torior', 'dzdzzdzdzd', 'nowakowski', '2021-02-08 12:15:49', 'dzdz'),
(37, 'Torior', 'FGDFGSDGFGFDSDFG', 'TERGESR', '2021-02-10 08:52:30', 'dazdazda'),
(38, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 09:33:02', '06292929292'),
(39, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 09:35:28', '06292929292'),
(40, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 09:38:43', '06292929292'),
(41, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 09:40:57', '06292929292'),
(42, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 09:41:20', '06292929292'),
(43, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 09:42:54', '06292929292'),
(44, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 09:57:17', '06292929292'),
(45, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 09:57:33', '06292929292'),
(46, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 09:58:15', '06292929292'),
(47, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 10:02:54', '06292929292'),
(48, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 10:06:49', '06292929292'),
(49, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 10:07:21', '06292929292'),
(50, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 10:16:36', '06292929292'),
(51, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 10:17:00', '06292929292'),
(52, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 10:18:57', '06292929292'),
(53, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 11:10:34', '06292929292'),
(54, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 11:43:09', '06292929292'),
(55, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 11:45:58', '06292929292'),
(56, 'Torior', 'KAKAAKAKA', 'nowakowski', '2021-02-10 11:50:35', '06292929292');

-- --------------------------------------------------------

--
-- Structure de la table `consulter`
--

DROP TABLE IF EXISTS `consulter`;
CREATE TABLE IF NOT EXISTS `consulter` (
  `ID_MESSAGE` bigint(4) NOT NULL,
  `ID_PSEUDO` char(32) NOT NULL,
  `VU` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID_MESSAGE`,`ID_PSEUDO`),
  KEY `I_FK_CONSULTER_M_MESSAGE` (`ID_MESSAGE`),
  KEY `I_FK_CONSULTER_PERSONNE` (`ID_PSEUDO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `c_contact`
--

DROP TABLE IF EXISTS `c_contact`;
CREATE TABLE IF NOT EXISTS `c_contact` (
  `CONTACT_MAIL` char(255) NOT NULL,
  `CONTACT_NOM` char(32) DEFAULT NULL,
  PRIMARY KEY (`CONTACT_MAIL`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `c_contact`
--

INSERT INTO `c_contact` (`CONTACT_MAIL`, `CONTACT_NOM`) VALUES
('FEZRFAZEF@F', 'ZEFAZEF'),
('meedlaah@gmail.com', 'zaefzaefazef'),
('FAZERFAZEOFKQSLF@DEFLKQSKLDFG', 'FEZRLFSLDF'),
('lahcen.agricu@gmail.com', 'DEZDAZEDZAE'),
('lekokin@gmail.com', 'marcel'),
('marcel.1999@live.fr', 'kaka');

-- --------------------------------------------------------

--
-- Structure de la table `demande`
--

DROP TABLE IF EXISTS `demande`;
CREATE TABLE IF NOT EXISTS `demande` (
  `ID_DEMANDE` int(11) NOT NULL AUTO_INCREMENT,
  `PSEUDO` varchar(32) NOT NULL,
  `MDP` varchar(32) NOT NULL,
  `NOM` char(32) NOT NULL,
  `PRENOM` char(32) NOT NULL,
  `AGE` int(2) NOT NULL,
  `TWITTER` text NOT NULL,
  `IMAGE` varchar(128) NOT NULL,
  `POURQUOINOUS` text NOT NULL,
  `EMAIL` varchar(127) NOT NULL,
  PRIMARY KEY (`ID_DEMANDE`)
) ENGINE=MyISAM AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `demande`
--

INSERT INTO `demande` (`ID_DEMANDE`, `PSEUDO`, `MDP`, `NOM`, `PRENOM`, `AGE`, `TWITTER`, `IMAGE`, `POURQUOINOUS`, `EMAIL`) VALUES
(47, 'sel', 'ccace46bc8b06a8e5a7e979f31da66b2', 'nowako', 'marcel', 20, 'sel_ftn', '6012c573a79151.48989541.png', 'PPPPPPPPIPIP', ''),
(48, 'efzafe', 'aace0e24a77994e07d141ea2d279e8b9', 'ffezfzefzef', 'fzefzeafzea', 15, 'fezafzeafza', '60130592782ec3.93166721.jpg', 'zefazefafze', ''),
(49, 'zerfzef', '96166aaf1d6899bbfee79a7c91e64ef1', 'xd', 'marcel', 15, 'fzefezrf', '601305ac5fa622.57762443.png', 'mpfdzefzef', ''),
(51, '', '24a2f6d124e089cb16a5135714e9df02', 'azefazefazef', 'zaefazefazef', 15, 'fazefaze', 'img/60181d94b809f2.67506586.png', 'czefazefzef', ''),
(52, 'FEVZER', '24a2f6d124e089cb16a5135714e9df02', 'azdazdazd', 'azdazdazdad', 15, 'zadazdazd', 'img/60181dd2a27243.23466923.png', 'ziza le kika', ''),
(53, 'ca cazecazecazec', '95646dc6b6667179c8f653bad93b86c0', 'zedzedzaed', 'azedazedazedaz', 15, 'edazedazed', 'img/60181e45714e29.23508093.png', 'ziza', ''),
(54, 'FEVZER', '24a2f6d124e089cb16a5135714e9df02', 'zdzedazed', 'azedazedazedaz', 15, 'edazed', 'img/60181e8fcaced2.79257320.png', 'dazedazedazed', ''),
(55, 'dfzedazed', 'a8b99b06a9c9b8c7e454cfe8bb5f7ffb', 'azedazedazed', 'azedazedazedazed', 15, 'zaedazed', 'img/601822491d2505.98961965.jpg', 'dzadze', ''),
(56, 'FZEFZEF', 'fa931c78da20dbe0c552054c74e019f5', 'DZEDEZ', 'med', 15, 'FZEZEFZFE', '60251adc42b166.71476125.png', 'FZEFZEFFZKKERLFGKERFLERFKERFAEZRFAZERFAERFAZFZAEFZEFZAEFAZEFAZFZFEZEFFAEZFAZEFAZEFAZEF', ''),
(57, 'zefzfzefzefzefzefezfz', 'ebfa24fe050bab026e47bc8958e97311', 'fezfzef', 'fzefzeff', 15, 'zefzefzefzefzefzef', '60251b5a5d1216.68588392.png', 'fzefzefezfzefzfzfezzfzeezezfzfeezfzfzfeezffezfzefezfzefzeffzfzeezfzefzefzeezf zfe zefezfez fezf ', ''),
(58, 'FEVZERfaezf', '24a2f6d124e089cb16a5135714e9df02', 'azefazefzae', 'fzaefazefazef', 15, 'fffzefazefazefazef', '60251bb70b05c8.49926572.png', ' fzefezafzaeffazefezf fzefezafzaeffazefezf fzefezafzaeffazefezf fzefezafzaeffazefezf v fzefezafzaeffazefezf fzefezafzaeffazefezf fzefezafzaeffazefezf ', ''),
(59, 'FEVZERfaezf', '24a2f6d124e089cb16a5135714e9df02', 'azefazefzae', 'fzaefazefazef', 15, 'fffzefazefazefazef', '60251bd19faa81.28468184.png', ' fzefezafzaeffazefezf fzefezafzaeffazefezf fzefezafzaeffazefezf fzefezafzaeffazefezf v fzefezafzaeffazefezf fzefezafzaeffazefezf fzefezafzaeffazefezf ', ''),
(60, 'FEVZER', '24a2f6d124e089cb16a5135714e9df02', 'fzfaerzfzerfzerfzerf', 'ferfaerfezrzerfezrfezrfzerfzer', 15, 'faerfzerfzerf', '60251c628a1128.44754878.png', 'fzerfzerferfzerfzefzerfzerferfzerfzefzerfzerferfzerfzefzerfzerferfzerfzefzerfzerferfzerfzefzerfzerferfzerfzefzerfzerferfzerfzefzerfzerferfzerfzefzerfzerferfzerfze', ''),
(61, 'sqdfsqdfsqdf', 'a267daf45e8373c330fd6ab42b098271', 'errfssqd', 'med', 15, 'gssfdqsdf', '60251ca81dd3f4.53630824.png', 'qsdfgsfdgsdfgsdfgsdfqsdfgsfdgsdfgsdfgsdfqsdfgsfdgsdfgsdfgsdfqsdfgsfdgsdfgsdfgsdfqsdfgsfdgsdfgsdfgsdfqsdfgsfdgsdfgsdfgsdfqsdfgsfdgsdfgsdfgsdfqsdfgsfdgsdfgsdfgsdf', ''),
(62, 'azedazedazedazed', '08a5d0379a2f2a714eac179a7022ca40', 'azedazedazedazedza', 'zaedazedazedazdeazed', 15, 'azedazedazedezad', '60251cd67ef1e5.70641420.png', 'dazedzaedzaedzaeddazedzaedzaedzaeddazedzaedzaedzaeddazedzaedzaedzaeddazedzaedzaedzaeddazedzaedzaedzaeddazedzaedzaedzaeddazedzaedzaedzaeddazedzaedzaedzaeddazedzaedzaedzaeddazedzaedzaedzaeddazedzaedzaedzaed', ''),
(63, 'FEVZER', '45fd27e714bab1bbf126997e15fae3b2', 'zrelfskdlfqfq', 'fezkfosqdfsl', 15, 'fqsdfqsdfqsdfqsdfqsdf', '60251d769195e8.85101294.png', 'zelkqsdlfqsdfqsdfqsdfzelkqsdlfqsdfqsdfqsdfzelkqsdlfqsdfqsdfqsdfzelkqsdlfqsdfqsdfqsdfzelkqsdlfqsdfqsdfqsdfzelkqsdlfqsdfqsdfqsdfzelkqsdlfqsdfqsdfqsdfzelkqsdlfqsdfqsdfqsdfzelkqsdlfqsdfqsdfqsdfzelkqsdlfqsdfqsdfqsdfzelkqsdlfqsdfqsdfqsdf', ''),
(64, 'FEVZER', '277c37d2066942115b51fa6c30c8a6a9', 'azefzaefzaefzaef', 'azefazefazefzaef', 15, 'azfefazefazef', '602524d77c9ac3.09974868.png', 'azefazefazefzafazefazefazefzafazefazefazefzafazefazefazefzafazefazefazefzafazefazefazefzafazefazefazefzafazefazefazefzafazefazefazefzafazefazefazefzaf', ''),
(65, 'ddqsdqsdqdqd', 'f1b97b4b9c482791852eb7d6012ea327', 'fqsfqsdfsqdffqsdfqedqs', 'fqsfqsdfsqdffqsdfqedqs', 15, 'fqsfqsdfsqdffqsdfqedqs', 'img/6029738e333d27.47421417.png', 'fqsfqsdfsqdffqsdfqedqsfqsfqsdfsqdffqsdfqedqsfqsfqsdfsqdffqsdfqedqsfqsfqsdfsqdffqsdfqedqsfqsfqsdfsqdffqsdfqedqsfqsfqsdfsqdffqsdfqedqsfqsfqsdfsqdffqsdfqedqsfqsfqsdfsqdffqsdfqedqsfqsfqsdfsqdffqsdfqedqs', 'meedlaah@gmail.com'),
(66, 'marcelgzebi', 'f1b97b4b9c482791852eb7d6012ea327', 'cdqsdqsdqs', 'marcel zebi', 15, 'dsfsqqdfsqdfdqsfsqff', 'img/602973d14ca386.54980600.png', 'dsfsqqdfsqdfdqsfsqffdsfsqqdfsqdfdqsfsqffdsfsqqdfsqdfdqsfsqffdsfsqqdfsqdfdqsfsqffdsfsqqdfsqdfdqsfsqffdsfsqqdfsqdfdqsfsqffdsfsqqdfsqdfdqsfsqffdsfsqqdfsqdfdqsfsqffdsfsqqdfsqdfdqsfsqffdsfsqqdfsqdfdqsfsqffdsfsqqdfsqdfdqsfsqff', 'meedlaah@gmail.com'),
(67, 'QSDFQSDFQSDFSQ', 'f1b97b4b9c482791852eb7d6012ea327', 'lalalalalaa', 'lalalalala', 15, 'sqdfqsdfqsdfqs', '602979c268f706.56984526.png', 'sdqfqsdfqsdfqsfqsfdsdqfqsdfqsdfqsfqsfdsdqfqsdfqsdfqsfqsfdsdqfqsdfqsdfqsfqsfdsdqfqsdfqsdfqsfqsfdsdqfqsdfqsdfqsfqsfdsdqfqsdfqsdfqsfqsfdsdqfqsdfqsdfqsfqsfdsdqfqsdfqsdfqsfqsfdsdqfqsdfqsdfqsfqsfdsdqfqsdfqsdfqsfqsfdsdqfqsdfqsdfqsfqsfdsdqfqsdfqsdfqsfqsfdsdqfqsdfqsdfqsfqsfdsdqfqsdfqsdfqsfqsfd', 'meedlaah@gmail.com'),
(68, 'ezrfezrfzefrzerf', 'd971a4c9a8214d5447e81a22869929e1', 'ezrfezrfzefrzerf', 'ezrfezrfzefrzerf', 15, 'ezrfezrfzefrzerf', '60297c5b6377b3.26420877.png', 'ezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerf', 'meedlaah@gmail.com'),
(69, '', 'f1b97b4b9c482791852eb7d6012ea327', 'ezrfezrfzefrzerf', 'ezrfezrfzefrzerf', 15, 'ezrfezrfzefrzerf', '60298814278fc5.42064982.png', 'ezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerf', 'meedlaah@gmail.com'),
(70, '', 'f1b97b4b9c482791852eb7d6012ea327', 'ezrfezrfzefrzerf', 'ezrfezrfzefrzerf', 15, 'ezrfezrfzefrzerf', '6029893af42323.97032851.png', 'ezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerf', 'meedlaah@gmail.com'),
(71, 'ezrfezrfzefrzerf', 'f1b97b4b9c482791852eb7d6012ea327', 'ezrfezrfzefrzerf', 'ezrfezrfzefrzerf', 15, 'ezrfezrfzefrzerf', '60298965e644f9.07975844.png', 'ezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerf', 'meedlaah@gmail.com'),
(72, 'meedlaaaah', '496b4ba01afded97eb787a4df8b53c66', 'ezrfezrfzefrzerf', 'ezrfezrfzefrzerf', 15, 'ezrfezrfzefrzerf', '602995d63e8a36.18524303.png', 'ezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerf', 'meedlaah@gmail.com'),
(73, 'meedlaaaahqsdd', '496b4ba01afded97eb787a4df8b53c66', 'ezrfezrfzefrzerf', 'ezrfezrfzefrzerf', 15, 'ezrfezrfzefrzerf', '6029976e5cb157.84105014.png', 'ezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerfezrfezrfzefrzerf', 'meedlaah@gmail.com'),
(74, 'sel1234', 'ffd926a6aae51c6ed612be9e7e15a2e6', 'nowakowski', 'marcel', 15, 'marcelle', '60338e2b63f9a6.52065381.png', 'je veux rejoindre fefefffffffffffffffffff je veux rejoindre fefefffffffffffffffffff', 'marcel.1999@live.fr'),
(75, 'selselsle', 'ccace46bc8b06a8e5a7e979f31da66b2', 'nowakowko', 'pierre', 18, 'sel_ftn', '6036dda2934f87.30198084.png', 'je veux rejointre team ryoken car je vvvvvvvvvvvvvvvvvvvvvvv', 'marcel.1999@live.fr');

-- --------------------------------------------------------

--
-- Structure de la table `facture`
--

DROP TABLE IF EXISTS `facture`;
CREATE TABLE IF NOT EXISTS `facture` (
  `ID_COMMANDE` bigint(4) NOT NULL,
  `ID_FACTURE` char(32) NOT NULL,
  `DATEFACTURATION` char(32) DEFAULT NULL,
  `statue` text NOT NULL,
  `payement` text NOT NULL,
  PRIMARY KEY (`ID_FACTURE`),
  KEY `I_FK_FACTURE_COMMANDE` (`ID_COMMANDE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `m_message`
--

DROP TABLE IF EXISTS `m_message`;
CREATE TABLE IF NOT EXISTS `m_message` (
  `ID_MESSAGE` bigint(4) NOT NULL AUTO_INCREMENT,
  `CONTACT_MAIL` char(255) NOT NULL,
  `DATE_HEURE` timestamp NULL DEFAULT NULL,
  `MESSAGE` text,
  PRIMARY KEY (`ID_MESSAGE`),
  KEY `I_FK_M_MESSAGE_C_CONTACT` (`CONTACT_MAIL`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `panier`
--

DROP TABLE IF EXISTS `panier`;
CREATE TABLE IF NOT EXISTS `panier` (
  `ID_PSEUDO` char(32) NOT NULL,
  `NOM_ARTICLES` char(32) NOT NULL,
  `NOMBRE_ARTICLES` smallint(127) NOT NULL,
  PRIMARY KEY (`ID_PSEUDO`,`NOM_ARTICLES`),
  KEY `NOM_ARTICLES` (`NOM_ARTICLES`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `panier`
--

INSERT INTO `panier` (`ID_PSEUDO`, `NOM_ARTICLES`, `NOMBRE_ARTICLES`) VALUES
('Torior', 'mohameddddddddd', 3),
('Torior', 'LAHIN3EL TABON MOK', 5),
('Torior', 'fazfazfazeazef', 5),
('Torior', 'ARTICLE DE QALITI WOLA', 1);

-- --------------------------------------------------------

--
-- Structure de la table `partenaires`
--

DROP TABLE IF EXISTS `partenaires`;
CREATE TABLE IF NOT EXISTS `partenaires` (
  `NOM_PARTENAIRE` char(32) NOT NULL,
  `SITE` text,
  PRIMARY KEY (`NOM_PARTENAIRE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `personne`
--

DROP TABLE IF EXISTS `personne`;
CREATE TABLE IF NOT EXISTS `personne` (
  `ID_PSEUDO` char(32) NOT NULL,
  `AGE` int(2) DEFAULT NULL,
  `NOM` char(32) DEFAULT NULL,
  `PRENOM` char(32) DEFAULT NULL,
  `MDP` char(32) DEFAULT NULL,
  PRIMARY KEY (`ID_PSEUDO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
