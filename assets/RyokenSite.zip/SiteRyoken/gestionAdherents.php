<?php
if (isset($_SESSION["IDENTIFIANT"])) {
    require_once './include/enteteAdmin.php';
} else {
    header("location: index.php?action=10");
    exit();
}

switch ($_REQUEST['action'])
{
case listeAdherent:
?>
<div class="container">
    <table class="table border border-primary" style="margin-top:30px;  ">
        <thead style="color:grey; width:100px;  ">
            <tr>
                <th scope="col">Identifiant</th>
                <th scope="col">Nom</th>
                <th scope="col">Prenom</th>
                <th scope="col">Age</th>
                <th scope="col">Description</th>
                <th scope="col">statut</th>
            </tr>
        </thead>
        <?php
    echo tableAdherents();
break;

case AjouterAdherent:
if (isset($_POST['ajouter'])) {
    $id=$_POST["IdentifiantNouveauAdh"];
    $mdp=$_POST["MdpNouveauAdh"];
    $description=$_POST["DescriptionNouveauAdh"];
    $age=$_POST["AgeNouveauAdh"];
    $prenom=$_POST["PrenomNouveauAdh"];
    $nom=$_POST["NomNouveauAdh"];
    $twitter=$_POST["TwitterNouveauAdh"];
    $statut=$_POST["StatutNouveauAdh"];
    $role=$_POST["RôleNouveauAdh"];

    $file=$_FILES["file"];
    $fileName=$_FILES["file"]["name"];
    $fileTmpName=$_FILES["file"]["tmp_name"]; // localisation temporaire du fichier.
    $fileSize=$_FILES["file"]["size"];
    $fileError=$_FILES["file"]["error"];
    $fileType=$_FILES["file"]["type"];
  
    $fileSplit=explode('.',$fileName);
    $fileExtension=strtolower(end($fileSplit)); // recupérer l'extension du fichier.

  if($fileError===0){
    if ($fileSize<1000000){
      $unique_name = uniqid('',true). '.' . $fileExtension; // donner un nom unique au fichier
      $FileDestination="img/".$unique_name;
      move_uploaded_file($fileTmpName, $FileDestination); // envoyer le fichier
      echo AjouterAdherent($statut,$role,$id,$mdp, $prenom, $nom,$description,$age,$twitter,$FileDestination);
    }
    else{
      echo "<script> alert('Choisisssez une image inferieur à 10 megabits.')</script>";
    }
  }
  else{
    echo "<script> alert('Une erreur est survenue lors du téléchargment du fichier..')</script>";
  }
    

}?>

        <div class="container rounded"
            style=" color:white!important; background: rgba(97, 97, 97, 0.329); margin-top:30px; ">
            <center>
                <h3>Ajouter un adhérent </h3>
            </center>

            <form method="post" action="index.php?action=100" enctype="multipart/form-data">
                <div class="row justify-content-between">
                    <div class="col-md-5" style="margin:0px 20px 20px 20px;">

                        <?php
$resultat=listStatut();  
$ligne = $resultat->setFetchMode(PDO::FETCH_NUM);
$ligne = $resultat->fetch();
$html="";
?>
                        <label for="StatutNouveauAdh">Statut de l'adhérent : </label>
                        <select name="StatutNouveauAdh" id="StatutNouveauAdh" class="form-control">
                            <?php
while ($ligne){
    $html.='<option value="'.$ligne[0].'">'.$ligne[0].'</option>';
    $ligne = $resultat->fetch();
}

echo $html;?>

                        </select>
                        <label for="RôleNouveauAdh">Rôle : </label>
                        <input id="RôleNouveauAdh" type='text' class="form-control" required name="RôleNouveauAdh"
                            placeholder="Entrer le rôle :"></input>
                        <label for="IdentifiantNouveauAdh">Saisissez l'identifiant : </label>
                        <input id="IdentifiantNouveauAdh" type='text' class="form-control" required
                            name="IdentifiantNouveauAdh" placeholder="Entrer l'identifiant"></input>

                        <label for="MdpNouveauAdh">Saisissez un mot de passe : </label>
                        <input id="MdpNouveauAdh" type='password' class="form-control" required name="MdpNouveauAdh"
                            placeholder="Entrer l'identifiant"></input>

                        <label for="NomNouveauAdh">Saisissez le nom : </label>
                        <input id="NomNouveauAdh" type='text' class="form-control" required name="NomNouveauAdh"
                            placeholder="Entrer le nom"></input>

                        <label for="PrenomNouveauAdh">Saisissez le prénom : </label>
                        <input id="PrenomNouveauAdh" type='text' class="form-control " required name="PrenomNouveauAdh"
                            placeholder="Entrer le prénom"></input>
                    </div>
                    <div class="col-md-5" style="margin:0px 20px 20px 20px;">
                        <label for="AgeNouveauAdh">Saisissez un age : </label>
                        <input id="AgeNouveauAdh" type='number' class="form-control " min=15 max=70 value="15"
                            name="AgeNouveauAdh"></input>

                        <label for="TwitterNouveauAdh">Lien de twitter : </label>
                        <input id="TwitterNouveauAdh" type='text' class="form-control " name="TwitterNouveauAdh"
                            placeholder="Entrer le prénom"></input>

                        <label for="DescriptionNouveauAdh">Saisissez une description : </label>
                        <textarea id="DescriptionNouveauAdh" name="DescriptionNouveauAdh" class="form-control"
                            placeholder="Entrer la description" rows="5"></textarea>

                        <label for="file"> Photo profil: </label>
                        <input type="file" id="file" name="file" style="color:white!important; margin-top:10px"
                        accept="image/png, image/jpeg"> <br>

                        <input type='submit' value='ajouter' class="btn btn-primary " style="margin-top:10px"
                            name='ajouter'>
                        </input>
                    </div>
                </div>
            </form>
        </div>

        <?php 
break; 

case ModifierAdherent:
if (isset($_POST["Modifier"])){
    $nom=$_POST["NomAdh"];
    $prenom=$_POST["PrenomAdh"];
    $identif=$_POST["listeAdherent"];
    $MDP=$_POST["MdpAdh"];
    $description=$_POST["DescriptionAdh"];
    $age=$_POST["AgeAdh"];
    $twitter=$_POST["TwitterAdh"];
    $role=$_POST["RôleAdh"];
    $statut=$_POST["listeStatut"];
    echo ModifierAdherent($nom,$prenom,$identif,$age,$statut,$role,$description,$twitter);
}
?>
        <div class="container rounded"
            style=" color:white!important; background: rgba(97, 97, 97, 0.329); margin-top:30px; ">
            <center>
                <h3>Modifier un adhérent : </h3>
            </center>


            <form method="post" action="index.php?action=120">
                <div class="row justify-content-between">
                    <div class="col-md-5" style="margin:0px 20px 20px 20px;">
                        <?php
$resultat=ListeAdherent();  
$ligne = $resultat->setFetchMode(PDO::FETCH_NUM);
$ligne = $resultat->fetch();
$html="";
?>
                        <label for="ListeAdherentModifier">L'adhérent : </label>
                        <select name="listeAdherent" id="ListeAdherentModifier" class="form-control">
                            <?php
while ($ligne){
    $html.='<option value="'.$ligne[0].'">'.$ligne[1].'</option>';
    $ligne = $resultat->fetch();
}
echo $html;?>
                        </select>
                        <?php
$resultat=listStatut();  
$ligne = $resultat->setFetchMode(PDO::FETCH_NUM);
$ligne = $resultat->fetch();
$html="";
?>
                        <label for="ListeStatutModifier">Statut de l'adhérent : </label>
                        <select name="listeStatut" id="ListeStatutModifier" class="form-control">
                            <?php
while ($ligne){
    $html.='<option value="'.$ligne[0].'">'.$ligne[0].'</option>';
    $ligne = $resultat->fetch();
}
echo $html;?>
                        </select>

                        <label for="RôleAdh">Rôle : </label>
                        <input id="RôleAdh" type='text' class="form-control" required name="RôleAdh"
                            placeholder="Entrer le rôle :"></input>

                        <label for="MdpAdh">Saisissez un mot de passe : </label>
                        <input id="MdpAdh" type='password' class="form-control" required name="MdpAdh"
                            placeholder="Entrer l'identifiant"></input>

                        <label for="NomAdh">Saisissez le nom : </label>
                        <input id="NomAdh" type='text' class="form-control" required name="NomAdh"
                            placeholder="Entrer le nom"></input>

                        <label for="PrenomAdh">Saisissez le prénom : </label>
                        <input id="PrenomAdh" type='text' class="form-control " required name="PrenomAdh"
                            placeholder="Entrer le prénom"></input>
                    </div>
                    <div class="col-md-5" style="margin:0px 20px 20px 20px;">
                        <label for="AgeAdh">Saisissez un age : </label>
                        <input id="AgeAdh" type='number' class="form-control " min=15 max=70 value="15"
                            name="AgeAdh"></input>

                        <label for="TwitterAdh">Lien de twitter : </label>
                        <input id="TwitterAdh" type='text' class="form-control " name="TwitterAdh"
                            placeholder="Entrer le prénom"></input>

                        <label for="DescriptionAdh">Saisissez une description : </label>
                        <textarea id="DescriptionAdh" name="DescriptionAdh" class="form-control"
                            placeholder="Entrer la description" rows="5"></textarea>

                        <input type='submit' value='Modifier' class="btn btn-primary " style="margin-top:10px"
                            name='Modifier'>
                        </input>
                    </div>
                </div>
            </form>
        </div>
        <?php
break;
case SuprimmerAdherent:
    if (isset($_POST["Supprimer"])){
        if($_POST["adherent"]==$_SESSION["IDENTIFIANT"]){
            echo '<script> alert("Vous ne pouvez pas vous supprimer") </script>';
        }else {
            $identif=$_POST["adherent"]; 
            echo SupprimerAdherent($identif);
            echo '<script> alert("Adherent du pseudo '. $identif .' supprimé") </script>';
        }
    }
?>

        <div class="container rounded" style="color:white; width: 50%; margin-top:4%; margin-bottom:4%; padding:2%; background:rgba(97, 97, 97, 0.329); ">
            <div class="delete">
                <h3>Supprimer un adhérent </h3>
                <form method="post" action="index.php?action=110">
                    <?php // liste des membres
        echo formSelectDepuisRecordset("Choisissez l'adhérent: ", "adherent","adherentUpdate", ListeAdherent(),20); 
        // submit devrai être controllé 
        ?>

                    <input type='submit' value='Valider' name='Supprimer'></input>
                </form>
            </div>
        </div>
        <?php
break;

case GestionDemande:
    if (isset($_POST["SubmitDemande"])){
        $nom=$_POST["NomDemande"];
        $prenom=$_POST["PrenomDemande"];
        $identif=intval($_POST["listeDemande"]);
        $pseudo=$_POST["PseudoDemande"];
        $MDP=$_POST["mdpDemande"]; //stock le mot de passe ici , grâce à une requete qui va prendre en paramètre l'id du demandeur
        $description=$_POST["DescriptionDemande"];
        $age=$_POST["AgeDemande"];
        $twitter=$_POST["TwitterDemande"];
        $role=$_POST["RôleDemande"];
        $statut=$_POST["listeStatutDemande"];
        $ReponseAdhesion=$_POST["ReponseAdhesion"];
        $image=$_POST["imgDemande"];
        echo "<script> alert(".$identif.") </script>";

        if ($_POST["ReponseAdhesion"]==1){
            echo AjouterAdherent($statut,$role,$pseudo,md5($MDP), $prenom, $nom,$description,$age,$twitter,$image);
            echo SupprimerDemande($identif); 
        } else  if ($_POST["ReponseAdhesion"]==0){
            echo SupprimerDemande($identif);
        }else if ($_POST["ReponseAdhesion"]==NULL){
            echo '<script> alert("Vous devez accepter ou refuser la demande avant de la soummettre") </script>';
        }    
    }
        ?>
        <div class="container rounded"
            style=" color:white!important; background: rgba(97, 97, 97, 0.329); margin-top:30px; ">
            <center>
                <h3>Les demandes d'adhésion : </h3>
            </center>


            <form method="post" action="index.php?action=<?php echo GestionDemande ?>">
                <img id="PhotoDemande" src="./img/maillot_ryokenv2.png"
                    style="width:200px; height:200px;"></a>
                <div class="row justify-content-between">

                    <div class="col-md-5" style="margin:0px 20px 20px 20px;">

                        <?php
    $resultat=ListDemandeur();  
    $ligne = $resultat->setFetchMode(PDO::FETCH_NUM);
    $ligne = $resultat->fetch();
    $html="";
?>
                        <label for="listeDemande">Les demandeurs : </label>
                        <select name="listeDemande" id="listeDemande" class="form-control">
                            <?php
    while ($ligne){
        $html.='<option value='.$ligne[0].'>'.$ligne[1].'</option>';
        $ligne = $resultat->fetch();
}
    echo $html;?>
                        </select>
                        <input id="mdpDemande" name="mdpDemande" type='hidden' class="form-control" value=""></input>
                       
                        <input id="imgDemande" name="imgDemande" type='hidden' class="form-control" value=""></input>
                        <label for="NomDemande">Le nom du demandeur : </label>


                        <input id="NomDemande" name="NomDemande" type='text' class="form-control" readonly
                            placeholder="Entrer le nom"></input>

                            
                
                        <label for="PrenomDemande">Le Pseudo du demandeur : </label>
                        <input id="PseudoDemande" name="PseudoDemande" type='text' class="form-control" value="" readonly></input>
                        

                        <label for="PrenomDemande">Le prénom du demandeur : </label>
                        <input id="PrenomDemande" name="PrenomDemande" type='text' class="form-control " readonly
                            placeholder="Entrer le prénom"></input>
                        <label for="PourquoiNousDemande">Pourquoi nous ? </label>
                        <textarea id="PourquoiNousDemande" name="PourquoiNousDemande" class="form-control" rows="5"
                            readonly></textarea>
                    </div>
                    <div class="col-md-5" style="margin:0px 20px 20px 20px;">
                        <label for="AgeDemande">L'âge du demandeur : </label>
                        <input id="AgeDemande" name="AgeDemande" type='number' class="form-control " min=15 max=70
                            value="15" readonly></input>

                        <label for="TwitterDemande">Lien de twitter du demandeur: </label>
                        <input id="TwitterDemande" name="TwitterDemande" type='text' class="form-control "
                            readonly></input>

                        <?php
    $resultat=listStatut();  
    $ligne = $resultat->setFetchMode(PDO::FETCH_NUM);
    $ligne = $resultat->fetch();
    $html="";
    ?>
                        <label for="listeStatutDemande">Statut de l'adhérent : </label>
                        <select name="listeStatutDemande" id="listeStatutDemande" class="form-control">
                            <?php
    while ($ligne){
        $html.='<option value="'.$ligne[0].'">'.$ligne[0].'</option>';
        $ligne = $resultat->fetch();
    }
    echo $html;?>
                        </select>

                        <label for="DescriptionDemande">Saisissez une description : </label>
                        <textarea id="DescriptionDemande" name="DescriptionDemande" class="form-control"
                            rows="5"></textarea>
                        <label for="RôleDemande">Rôle : </label>
                        <input id="RôleDemande" name="RôleDemande" type='text' class="form-control" required
                            placeholder="Entrer le rôle :"></input>

                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="ReponseAdhesion" value="1"
                                id="AcceptAdhesion">
                            <label class="form-check-label" for="AcceptAdhesion">
                                Accepter l'adhésion.
                            </label>
                        </div>

                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="ReponseAdhesion" value="0"
                                id="RefusAdhesion">
                            <label class="form-check-label" for="RefusAdhesion">
                                Refuser l'adhésion.
                            </label>
                        </div>

                        <input type='submit' value='soumettre' class="btn btn-primary " style="margin-top:10px"
                            name='SubmitDemande'>
                        </input>
                    </div>
                </div>
            </form>
        </div>
        <?php
break;
}
    ?>