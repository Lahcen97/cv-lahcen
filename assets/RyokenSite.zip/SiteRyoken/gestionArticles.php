<?php
if (isset($_SESSION["IDENTIFIANT"])) {
    require_once './include/enteteAdmin.php';
} else {
    header("location: index.php?action=10");
    exit();
}

switch ($_REQUEST['action'])
{
case ListeArticle:
?>
<div class="container">
    <table class="table border border-primary" style="margin-top:30px;  ">
        <thead style="color:grey; width:100px;  ">
            <tr>
                <th scope="col">Nom Articles</th>
                <th scope="col">Categorie</th>
                <th scope="col">Partenaire</th>
                <th scope="col">Prix d'origine</th>
                <th scope="col">Prix vente Unitaire</th>
                <th scope="col">image</th>
            </tr>
        </thead>
        <?php
    echo GetListeArticles();
    ?>
    </table>
</div>
<?php
break;
case ModifierArticle:
    if (isset($_POST["ModifierArticle"])){
        $id=$_POST["ListeArticlesModifier"];
        $NewName=$_POST["NomArticlesModifier"];
        $CategorieArticle=$_POST["CategorieArticleModifier"];
        $nomPartenaire=$_POST["NomPartenaireModifier"];
        $PrixArticle=$_POST["PrixOrigineModifier"];
        $PrixVenteUnitaire=$_POST["PrixVenteUnitaireModifier"];
       
        $file=$_FILES["file"];
        $fileName=$_FILES["file"]["name"];
        $fileTmpName=$_FILES["file"]["tmp_name"]; // localisation temporaire du fichier.
        $fileSize=$_FILES["file"]["size"];
        $fileError=$_FILES["file"]["error"];
        $fileType=$_FILES["file"]["type"];

        $fileSplit=explode('.',$fileName);
        $fileExtension=strtolower(end($fileSplit)); // recupérer l'extension du fichier.

         if($fileError===0){
            if ($fileSize<1000000){
                $unique_name = uniqid('',true). '.' . $fileExtension; // donner un nom unique au fichier
                $FileDestination="img/".$unique_name;
                move_uploaded_file($fileTmpName, $FileDestination); // envoyer le fichier
                echo modifierArticle($id, $NewName,$CategorieArticle,$nomPartenaire,$PrixArticle,$PrixVenteUnitaire,$FileDestination);
         }
         else{
           echo "<script> alert('Choisisssez une image inferieur à 10 megabits.')</script>";
          }
         }
         else{
          echo "<script> alert('Une erreur est survenue lors du téléchargment du fichier..')</script>";
  }
} ?>
<div class="container rounded" style=" color:white; margin-top:4%; margin-bottom:4%; padding:2%; background:rgba(97, 97, 97, 0.329);">
    <center>
        <h3>Modifier un article : </h3>
    </center>

    <form method="post" action="index.php?action=<?php echo ModifierArticle ?>" enctype="multipart/form-data">
        <div class="row justify-content-between">
            <div class="col-md-5" style="margin:0px 20px 20px 20px;">
                <?php
    $resultat=listArticle();  
    $ligne = $resultat->setFetchMode(PDO::FETCH_NUM);
    $ligne = $resultat->fetch();
    $html="";
    ?>
                <label for="ListeArticlesModifier">L'article : </label>
                <select name="ListeArticlesModifier" id="ListeArticlesModifier" class="form-control">
                    <?php
    while ($ligne){
        $html.='<option value="'.$ligne[0].'">'.$ligne[0].'</option>';
        $ligne = $resultat->fetch();
    }
    echo $html;?>
                </select>
                <label for="NomArticlesModifier">Nom de l'article : </label>
                <input id="NomArticlesModifier" type='text' class="form-control" required
                    name="NomArticlesModifier"></input>

                <label for="CategorieArticleModifier">Categorie : </label>
                <input id="CategorieArticleModifier" type='text' class="form-control" required
                    name="CategorieArticleModifier" placeholder="Entrer le rôle :"></input>

                <label for="NomPartenaireModifier">Nom Partenaire : </label>
                <input id="NomPartenaireModifier" type='text' class="form-control" required name="NomPartenaireModifier"
                    placeholder="Entrer l'identifiant"></input>

                <label for="PrixOrigineModifier">Prix Origine : </label>
                <input id="PrixOrigineModifier" type='number' class="form-control" required name="PrixOrigineModifier"
                    placeholder="Entrer le nom"></input>

                <label for="PrixVenteUnitaireModifier">Prix Vente Unitaire : </label>
                <input id="PrixVenteUnitaireModifier" type='number' class="form-control " required
                    name="PrixVenteUnitaireModifier" placeholder="Entrer le prénom"></input>


            </div>
            <div class="col-md-5">
                <img id="ImageArticleModifier" src="img/601305fccb6624.28034401.png"
                    style="width:100%; height:50%;"></a>
                <input type="file" id="file" name="file" style="color:white!important; margin-top:10px"
                    accept="image/png, image/jpeg"> <br>

                <input type='submit' value='Modifier' class="btn btn-primary " style="margin-top:10px"
                    name='ModifierArticle'>
                </input>
            </div>
        </div>
</div>
</form>
</div>
<?php
    break;
    case AjouterArticle:
        if (isset($_POST["submitArticle"])){
            $nomArticle=$_POST["NomArticles"];
            $CategorieArticle=$_POST["CategorieArticle"];
            $nomPartenaire=$_POST["NomPartenaire"];
            $PrixArticle=$_POST["PrixOrigine"];
            $PrixVenteUnitaire=$_POST["PrixVenteUnitaire"];
            $DescriptionArticle=$_POST["DescriptionArticle"];
            
            $file=$_FILES["file"];
            $fileName=$_FILES["file"]["name"];
            $fileTmpName=$_FILES["file"]["tmp_name"]; // localisation temporaire du fichier.
            $fileSize=$_FILES["file"]["size"];
            $fileError=$_FILES["file"]["error"];
            $fileType=$_FILES["file"]["type"];
            
            $fileSplit=explode('.',$fileName);
            $fileExtension=strtolower(end($fileSplit)); // recupérer l'extension du fichier.
          
            if($fileError===0){
              if ($fileSize<1000000){
                $unique_name = uniqid('',true). '.' . $fileExtension; // donner un nom unique au fichier
                $FileDestination="img/".$unique_name;
                move_uploaded_file($fileTmpName, $FileDestination); // envoyer le fichier
                echo ajouterArticle($nomArticle,$CategorieArticle,$nomPartenaire,$PrixArticle,$PrixVenteUnitaire,$DescriptionArticle,$FileDestination);
              }
              else{
                echo "<script> alert('Choisisssez une image inferieur à 10 megabits.')</script>";
              }
            }
            else{
              echo "<script> alert('Une erreur est survenue lors du téléchargment du fichier..')</script>";
            }
          } ?>
<div class="container rounded">
    <form action="index.php?action=<?php echo AjouterArticle ?>" method="post" enctype="multipart/form-data">
        <div class="row justify-content-between">
            <div class="col-md-5" style="color:white; margin-left:25%; margin-top:4%; margin-bottom:4%; padding:2%; background:rgba(97, 97, 97, 0.329); ">
                <label for="NomArticles"> Saisissez le nom de l'article : </label>
                <input id="NomArticles" name="NomArticles" type='text' class="form-control" required></input>

                <?php
$resultat=listCat();  
$ligne = $resultat->setFetchMode(PDO::FETCH_NUM);
$ligne = $resultat->fetch();
$html="";
?>
                        <label for="CategorieArticle">Entrez la categorie de l'article : </label>
                        <select name="CategorieArticle" id="CategorieArticle" class="form-control">
                            <?php
while ($ligne){
    $html.='<option value="'.$ligne[0].'">'.$ligne[0].'</option>';
    $ligne = $resultat->fetch();
}

echo $html;?>

                        </select>
                <label for="DescriptionArticle">Saisissez une description de l'article : </label>
                <textarea id="DescriptionArticle" name="DescriptionArticle" class="form-control"
                 placeholder="Entrer la description" rows="5"></textarea>
                <label for="NomPartenaire">Saisissez le nom du partenaire : </label>
                <input id="NomPartenaire" name="NomPartenaire" type='text' class="form-control "></input>

                <label for="PrixOrigine">Saisissez le prix d'origine : </label>
                <input id="PrixOrigine" name="PrixOrigine" type='number' class="form-control "></input>

                <label for="PrixVenteUnitaire">Saisissez le prix de vente : </label>
                <input id="PrixVenteUnitaire" name="PrixVenteUnitaire" type='number' class="form-control "></input>

                <label for="file"> Image de l'article </label>
                <input type="file" id="file" name="file" style="color:white!important; margin-top:10px"
                    accept="image/png, image/jpeg"> <br>

                <input type='submit' value='Soumettre' class="btn btn-primary" style="margin-top:10px"
                    name="submitArticle">
                </input>
            </div>
        </div>


    </form>
</div>
<?php
    break;
    case SupprimmerArticle:
        if (isset($_POST['SupprimmerArticle'])){
            $nom=$_POST['NomArticles'];
            echo SupprimerArticle($nom);
        }
       ?>
<div class="container rounded">
    <form method="post" action="index.php?action=<?php echo SupprimmerArticle ?>">
        <div class="row justify-content-between">
            <div class="col-md-5 container rounded" style="color:white; margin-left:25%; margin-top:4%; margin-bottom:4%; padding:2%; background:rgba(97, 97, 97, 0.329);">
                <?php
    $resultat=listArticle();  
    $ligne = $resultat->setFetchMode(PDO::FETCH_NUM);
    $ligne = $resultat->fetch();
    $html="";
    ?>
                <label for="NomArticles">Les articles : </label>
                <select name="NomArticles" id="NomArticles" class="form-control">
                    <?php
    while ($ligne){
        $html.='<option value="'.$ligne[0].'">'.$ligne[0].'</option>';
        $ligne = $resultat->fetch();
    }
    echo $html;?>
                </select>
                <input type='submit' value='Suprimmer' class="btn btn-primary " style="margin-top:10px"
                    name='SupprimmerArticle'>
                </input>
            </div>
        </div>
    </form>
</div>
<?php
    break;
}
?>
</body>

</html>