<?php
require_once "../include/BDD.php";


$demande=$_POST["demande"];
$requete='select demande.ID_DEMANDE as \'ID_DEMANDE\' , demande.nom as \'nom\',  demande.prenom as \'prenom\', '
    .' demande.age as \'age\', demande.pseudo as \'pseudo\', demande.pourquoinous as \'pourquoinous\', '
    .' demande.mdp as \'mdp\', demande.twitter as \'twitter\' , demande.image as \'image\' '
    .' from demande '
    .' where ID_DEMANDE="'. $demande .'"';
$preparation = SGBDConnect()->query($requete);
$ligne = $preparation->fetch(PDO::FETCH_ASSOC); 
echo json_encode($ligne);

?>