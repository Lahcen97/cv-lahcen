<?php
require_once "../include/BDD.php";

$article=$_POST["article"];
$requete='select articles.nom_articles as \'NomArticle\' , articles.libelle_categorie as \'CategorieArticle\' , articles.nom_partenaire as \'NomPartenaire\', '
    . 'articles.prixorigine as \'PrixOrigine\' , articles.prixventeunitaire  as \'PrixVenteUnitaire\' , articles.img_article as  \'ImageArticle\' '
    .' from articles '
    .' where nom_articles="'. $article .'"'; 

$preparation = SGBDConnect()->query($requete);

$ligne = $preparation->fetch(PDO::FETCH_ASSOC); 
echo json_encode($ligne);