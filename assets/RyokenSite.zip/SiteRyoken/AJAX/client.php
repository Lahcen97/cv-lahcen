<?php
require_once "../include/BDD.php";

$client=$_POST["client"];

$requete='select Clients.NOM as \'nom\' , Clients.PRENOM as \'prenom\',  Clients.AGE as \'age\', '
    .' Clients.PAYS as \'pays\', Clients.ADRESSE as \'adresse\', Clients.EMAIL as \'email\' '
    .' from clients '
    .' where id_pseudo="'. $client .'"';
$preparation = SGBDConnect()->query($requete);
$ligne = $preparation->fetch(PDO::FETCH_ASSOC); 
echo json_encode($ligne);

?>