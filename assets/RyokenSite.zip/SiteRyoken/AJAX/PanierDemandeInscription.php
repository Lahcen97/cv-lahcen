<?php 
$donne='<h1 style="margin-top:30px;"> Inscrivez-vous pour ajouter un article au panier. </h1>
<form action="index.php?action=150" id="FrmPaniercompte" method="post" >
<label for="IdentifiantNouveauCltPanier">Saisissez l\'identifiant : </label>
<input id="IdentifiantNouveauCltPanier" type="text" class="form-control" required name="IdentifiantNouveauCltPanier"
    placeholder="Entrer l\'identifiant"></input>

<label for="MdpNouveauCltPanier">Saisissez un mot de passe : </label>
<input id="MdpNouveauCltPanier" type="password" class="form-control" required name="MdpNouveauCltPanier"
    placeholder="Entrer l\'identifiant"></input>

<label for="NomNouveauCltPanier">Saisissez le nom : </label>
<input id="NomNouveauCltPanier" type="text" class="form-control" required name="NomNouveauCltPanier"
    placeholder="Entrer le nom"></input>

<label for="PrenomNouveauCltPanier">Saisissez le prénom : </label>
<input id="PrenomNouveauCltPanier" type="text" class="form-control " required name="PrenomNouveauCltPanier"
    placeholder="Entrer le prénom"></input>

<input type="submit" value="Créer un Compte" class="btn btn-primary " style="margin-top:10px; margin-bottom:10px;"
    name="inscrirePanier"></input>
    </form>';

echo json_encode($donne);