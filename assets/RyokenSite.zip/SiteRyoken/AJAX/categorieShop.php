<?php
require_once "../include/BDD.php";

$libelleCategorie=$_POST["libelleCategorie"];
$donnees=genererArticles($libelleCategorie);

echo json_encode($donnees);