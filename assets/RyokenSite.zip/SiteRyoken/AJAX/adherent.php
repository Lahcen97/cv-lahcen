<?php
require_once "../include/BDD.php";

$adherent=$_POST["adherent"];
$requete='select adherent.nom as \'nom\' , adherent.prenom as \'prenom\' , adherent.id_pseudo as \'pseudo\', '
    . 'adherent.age as \'age\' , adherent.statut  as \'statut\',  adherent.role as \'role\', '
    . 'adherent.description as \'description\' , adherent.twitter as \'twitter\', adherent.mdp as \'mdp\' '
    .' from adherent '
    .' where id_pseudo="'. $adherent .'"'; 

$preparation = SGBDConnect()->query($requete);

$ligne = $preparation->fetch(PDO::FETCH_ASSOC); 
echo json_encode($ligne);