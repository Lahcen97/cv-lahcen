<?php
require_once "../include/bdd.php";
require "../.php";

echo json_encode($html);

?>