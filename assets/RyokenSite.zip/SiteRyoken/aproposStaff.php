<?php
if (isset($_SESSION["TABLE"])){
  if($_SESSION["TABLE"]=="adherent"){ // gestion de l'affichage pour admin
    require_once './include/enteteAdmin.php';
  }
  else if ($_SESSION["TABLE"]=="clients") {  // gestion de l'affichage pour client
        require_once './include/enteteclient.php';
    }
}
else {// gestion de l'affichage pour les personnes deconnectées 
      require_once './include/entete.php';
    }

switch ($_REQUEST['action'])
    {
case AproposStaff:
?>
    <section id="apropos">
    <?php
    echo GetAdherentsApropos("Admin");
    ?>
    </section>
<?php
break;
case AproposJoueur:
?>
<section id="apropos">
    <?php
    echo GetAdherentsApropos("Utilisateur");
    ?>
</section>
<?php
  break;
}
  require_once './include/pied.php'
?>