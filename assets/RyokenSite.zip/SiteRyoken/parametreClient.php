<?php
if (isset($_SESSION["IDENTIFIANT"])) {
    require_once './include/enteteClient.php';
}else {
    header("location: index.php?action=10");
    exit();
}
?>
<?php
if (isset($_POST["Modifier"])) {
    $pseudo=$_SESSION["IDENTIFIANT"];
    $mdp=$_POST["mdpClt"];
    $nom=$_POST["NomClt"];
    $prenom=$_POST["PrenomClt"];
    $pays=$_POST["PaysClt"];
    $email=$_POST["EmailClt"];
    $adresse=$_POST["AdresseClt"];
    $age=$_POST["AgeClt"];
    echo ModifierClient ($nom,$prenom,$pays,$email,$adresse,$age,$pseudo,$mdp=null);
}
$id=$_SESSION['IDENTIFIANT'];
$ligne=InfoClient($id);
?>
<div class="container rounded" style=" color:white!important; background: rgb(186,196,209,0.3); margin-top:30px; ">
    <center>
        <h3>Modifier votre compte : </h3>
    </center>
    
    <form method="post" action="index.php?action=250">
        <div class="row justify-content-between">
            <div class="col-md-5" style="margin:0px 20px 20px 20px;">

                <label for="mdpClt">Saisissez un mot de passe : </label>
                <input id="mdpClt" type='password' class="form-control" required name="mdpClt"
                    value="<?php echo $ligne[0]; ?>"></input>

                <label for="NomClt">Saisissez le nom : </label>
                <input id="NomClt" type='text' class="form-control" required name="NomClt"
                    value="<?php echo $ligne[1]; ?>"></input>

                <label for="PrenomClt">Saisissez le prénom : </label>
                <input id="PrenomClt" type='text' class="form-control " required name="PrenomClt"
                    value="<?php echo $ligne[2]; ?>"></input>
                
                <label for="PaysClt">Saisissez votre pays: </label>
                <input id="PaysClt" type='text' class="form-control " name="PaysClt" value="<?php echo $ligne[3]; ?>"></input>

                <label for="EmailClt">email : </label>
                <input id="EmailClt" type='text' class="form-control " name="EmailClt"
                    value="<?php echo $ligne[4]; ?>"></input>
                
                <label for="AdresseClt">Adresse : </label>
                <input id="AdresseClt" type='text' class="form-control " name="AdresseClt"
                    value="<?php echo $ligne[5]; ?>"></input>

                <label for="AgeClt">Age : </label>
                <input id="AgeClt" type='age' class="form-control " name="AgeClt"
                    value="<?php echo $ligne[6]; ?>"></input>

                <input type='submit' value='Modifier' class="btn btn-primary " style="margin-top:10px; margin-bottom:10px" name='Modifier'>
                </input>
            </div>
        </div>
    </from>
</div>


