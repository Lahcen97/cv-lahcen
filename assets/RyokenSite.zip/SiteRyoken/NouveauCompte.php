<?php
require_once './include/entete.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
switch ($_REQUEST['action'])
{
case NouveauCompte:
?>
<?php if (!isset($_SESSION["IdentifiantNouveauClt"])){
    ?>

<form class="container rounded" action="index.php?action=<?php echo confirmationMailInscription; ?>" id="Frmnvcompte" method="post"
    onsubmit="return controleFrmInscription(this);">
    <label for="IdentifiantNouveauClt">Saisissez l'identifiant : </label>
    <input id="IdentifiantNouveauClt" type='text' class="form-control" required name="IdentifiantNouveauClt"
        placeholder="Entrer un identifiant"></input>

    <label for="MdpNouveauClt">Saisissez un mot de passe : </label>
    <input id="MdpNouveauClt" type='password' class="form-control" required name="MdpNouveauClt"
        placeholder="Entrer un mot de passe"></input>

    <label for="MdptestNouveauClt">Vérifiez le mot de passe : </label>
    <input id="MdptestNouveauClt" type='password' class="form-control" required name="MdptestNouveauClt"
        placeholder="Entrer une deuxieme fois le mot de passe"></input>

    <label for="emailNouveauClt">Saisissez Votre mail : </label>
    <input id="emailNouveauClt" type='email' class="form-control " required name="emailNouveauClt"
        placeholder="Entrer un mail"></input>

    <label for="NomNouveauClt">Saisissez votre nom : </label>
    <input id="NomNouveauClt" type='text' class="form-control" required name="NomNouveauClt"
        placeholder="Entrer un nom"></input>

    <label for="PrenomNouveauClt">Saisissez votre prénom : </label>
    <input id="PrenomNouveauClt" type='text' class="form-control " required name="PrenomNouveauClt"
        placeholder="Entrer un prénom"></input>

    <label for="PaysNouveauClt">Saisissez votre Pays : </label>
    <input id="PaysNouveauClt" type='text' class="form-control " required name="PaysNouveauClt"
        placeholder="Entrer un pays"></input>

    <label for="AgeNouveauClt">Saisissez votre age : </label>
    <input id="AgeNouveauClt" name="AgeNouveauClt" type='number' class="form-control" placeholder="Entrer un age" min=15
        max=70 value="15"></input>


    <br>
    <div class="g-recaptcha" data-sitekey="6LeQ6VQaAAAAAKopIiJ0bA0XfFBUpq79mWlCfDfo"></div>
    <input type='submit' value='Créer un Compte' class="btn btn-primary " style="margin-top:10px"
        name='inscrire'></input>
</form>

<?php } else if (isset($_SESSION["IdentifiantNouveauClt"])) {?>

<form action="index.php?action=<?php echo confirmationMailInscription; ?>" id="Frmnvcompte" method="post"
    onsubmit="return controleFrmInscription(this);">
    <label for="IdentifiantNouveauClt">Saisissez l'identifiant : </label>
    <input id="IdentifiantNouveauClt" type='text' class="form-control" required name="IdentifiantNouveauClt"
        value="<?php echo $_SESSION["IdentifiantNouveauClt"]?>"></input>

    <label for="MdpNouveauClt">Saisissez un mot de passe : </label>
    <input id="MdpNouveauClt" type='password' class="form-control" required name="MdpNouveauClt"
        placeholder="Entrer un mot de passe"></input>

    <label for="MdptestNouveauClt">Saisissez à nouveau le mot de passe : </label>
    <input id="MdptestNouveauClt" type='password' class="form-control" required name="MdptestNouveauClt"
        placeholder="Entrer une deuxime fois le mot de passe"></input>

    <label for="emailNouveauClt">Saisissez Votre mail : </label>
    <input id="emailNouveauClt" type='email' class="form-control " required name="emailNouveauClt"></input>

    <label for="NomNouveauClt">Saisissez le nom : </label>
    <input id="NomNouveauClt" type='text' class="form-control" required name="NomNouveauClt"
        value="<?php echo $_SESSION["NomNouveauClt"]?>"></input>

    <label for="PrenomNouveauClt">Saisissez le prénom : </label>
    <input id="PrenomNouveauClt" type='text' class="form-control " required name="PrenomNouveauClt"
        value="<?php echo $_SESSION["PrenomNouveauClt"]?>"></input>

    <label for="PaysNouveauClt">Saisissez le Pays : </label>
    <input id="PaysNouveauClt" type='text' class="form-control " required name="PaysNouveauClt"
        value="<?php echo $_SESSION["PaysNouveauClt"]?>"></input>

    <label for="AgeNouveauClt">Saisissez un age : </label>
    <input id="AgeNouveauClt" name="AgeNouveauClt" type='number' class="form-control"
        value="<?php echo $_SESSION["AgeNouveauClt"]?>" min=15 max=70 value="15"></input>

    <br>
    <div class="g-recaptcha" data-sitekey="6LeQ6VQaAAAAAKopIiJ0bA0XfFBUpq79mWlCfDfo"></div>
    <input type='submit' value='Créer un Compte' class="btn btn-primary " style="margin-top:10px"
        name='inscrire'></input>
</form>

<?php }
break;
case confirmationMailInscription:
require './PHPMailer/src/Exception.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';

if (isset($_POST["inscrire"])){

    if (isset($_POST['g-recaptcha-response'])){
        require('recaptcha-master/autoload.php');
        $recaptcha = new \ReCaptcha\ReCaptcha('6LeQ6VQaAAAAACb_3g6ge01w7f4mAWzK2ycVF_UQ');
        $resp = $recaptcha->verify($_POST['g-recaptcha-response']); 
        if ($resp->isSuccess()) {
            $_SESSION["NomNouveauClt"]=$_POST["NomNouveauClt"];
            $_SESSION["PrenomNouveauClt"]=$_POST["PrenomNouveauClt"];
            $_SESSION["IdentifiantNouveauClt"]=$_POST["IdentifiantNouveauClt"];
            $_SESSION["MdpNouveauClt"]=$_POST["MdpNouveauClt"];
            $_SESSION["emailNouveauClt"]=$_POST["emailNouveauClt"];
            $_SESSION["AgeNouveauClt"]=$_POST["AgeNouveauClt"];
            $_SESSION["PaysNouveauClt"]=$_POST["PaysNouveauClt"];  
        }
        else {
            $_SESSION["NomNouveauClt"]=$_POST["NomNouveauClt"];
            $_SESSION["PrenomNouveauClt"]=$_POST["PrenomNouveauClt"];
            $_SESSION["IdentifiantNouveauClt"]=$_POST["IdentifiantNouveauClt"];
            $_SESSION["AgeNouveauClt"]=$_POST["AgeNouveauClt"];
            $_SESSION["PaysNouveauClt"]=$_POST["PaysNouveauClt"];
            echo "<script> alert('Le captacha est invalide.')</script>";
            echo "<script type='text/javascript'> document.location.replace('index.php?action=150');</script>";
         }
        }
    }

if (isset($_SESSION["emailNouveauClt"])){
    // Envoyer le mail avec le code de confirmation
$adresseMail=$_SESSION["emailNouveauClt"];
$objet="Confirmation inscription Ryoken";
$name=$_SESSION["NomNouveauClt"];
$_SESSION["CodeVerificationClt"]=mt_rand (10000,99999);
$message="Bonjour Mr.".$name.", <br> votre code  de confirmation est  :" .$_SESSION["CodeVerificationClt"].".<br> Cordialement, <br> -L'equipe Ryoken. <br> <center> <img src='https://pbs.twimg.com/profile_images/1348343673939963904/65yHDRre.png'></center>";
$key="c86e0d7c45ca4b0ae07055e4687f4dc0";

$mail = new PHPMailer();  // Cree un nouvel objet PHPMailer
//$mail->IsSMTP(); // active SMTP
$mail->IsHTML(true);
$mail->SMTPDebug = 0;  // debogage: 1 = Erreurs et messages, 2 = messages seulement
$mail->SMTPAuth = true;  // Authentification SMTP active
$mail->SMTPSecure = 'ssl'; // Gmail REQUIERT Le transfert securise
$mail->Host = 'smtp.gmail.com';
$mail->Port = 465;
$mail->Username = 'ryoken.esport2021@gmail.com';
$mail->Password = md5($key);
$mail->SetFrom('ryoken.esport2021@gmail.com', 'Ryoken');
$mail->Subject = $objet;
$mail->Body = $message;
$mail->AddAddress($adresseMail);
if(!$mail->Send()) {
  echo 'Mail error: '.$mail->ErrorInfo;
} 
?>
<div class="container">
    <div class="row">
        <div class="col-md-12 rounded" style="margin-top:100px;margin-bottom:100px; background:rgb(218, 218, 218,0.4)">
            <center>
                <div class="ContenueDemandeAdherer">
                    <h3 style="color:white;"> Un code de verification à été envoyé à votre mail <b
                            style='color:rgb(4,137,203)'> <?php echo  $adresseMail  ?> </b></h3>
                    <form action="index.php?action=<?php echo VerificationCodeConfirmation; ?>" method="post">
                        <label for="CodeVerificationClt">Saisissez le code de vérification : </label>
                        <input type='text' id="CodeVerificationClt" name="CodeVerificationClt" class="form-control"
                            minlength="5" maxlength="5" style="width:50%;" required></input>
                        <input type='submit' value='Soumettre' class="btn btn-primary"
                            style="margin-top:10px; margin-bottom:10px" name="submitCltCodeVerfication"
                            id="submitCltCodeVerfication">
                        </input>
                    </form>
                </div>
            </center>
        </div>
    </div>
</div><?php
}else {
    echo "<script type='text/javascript'> document.location.replace('index.php?action=150');</script>";
}

break;
case VerificationCodeConfirmation:
    if  (isset($_POST["submitCltCodeVerfication"]) && $_POST["CodeVerificationClt"]==$_SESSION["CodeVerificationClt"]){
        $nom=$_SESSION["NomNouveauClt"];
        $prenom=$_SESSION["PrenomNouveauClt"];
        $age=$_SESSION["AgeNouveauClt"];
        $identif=$_SESSION["IdentifiantNouveauClt"];
        $MDP=$_SESSION["MdpNouveauClt"];
        $email=$_SESSION["emailNouveauClt"];
        $pays=$_SESSION["PaysNouveauClt"];
        echo AjouterClient($identif,md5($MDP),$prenom,$nom,$email,$age,$pays);
        session_destroy(); // si le code de verification est correct, on rajoute le demandeur dans la BD et on supprime les sessions. 
        ?>
<div class="container">
    <center>
        <div class="rounded"
            style="margin-top:100px; margin-bottom:100px; background:rgb(218, 218, 218,0.4); color:white; width:60%; height:50Vh;">
            <p> Votre inscription dans le site Ryoken à été bien prise en compte.
                <br> Si vous avez des questions, contactez nous via l'onglet en bas de la page.
                <br> L'équipe Ryoken vous remercie et vous souhaite la bienvenue.
            </p>
            <div>
    </center>
</div>
<?php
    }
    else if (isset($_POST["submitDemandeCodeVerfication"])  && $_POST["CodeDemande"]!==$_SESSION["CodeVerificationDemande"]) {
        ?>

<div class="container ">
    <center>
        <div class="rounded"
            style="margin-top:100px; margin-bottom:100px; background:rgb(218, 218, 218,0.4);  color:white; width:80%; height:50Vh;">
            <h3 style="margin-top:15px; margin-bottom:15px;"> le code de vérification est incorrecte. Veuillez ressayez
                à nouveau en cliquant ici.<br>
            </h3>
            <form action="index.php?action=<?php echo ConfirmationMail;  ?>" method="post">
                <input type='submit' value='Renvoyez le code' class='btn btn-primary'
                    style='margin-top:10px; margin-bottom:10px' name='IncorrectCodeVerificationClt'
                    id='IncorrectCodeVerificationClt'>
                </input>
            </form>
            <div>
    </center>
</div>


<?php
    }else { 
    echo "<script type='text/javascript'> document.location.replace('index.php?action=150');</script>";
    exit(); 
    }
    break;
}


require_once './include/pied.php'
?>