<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <script src="./jquery/jquery-3.5.1.min.js"> </script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="./img/Style.css" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <script src="https://www.google.com/recaptcha/api.js"></script>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
    <script src="./js/script.js"></script>
    <title>Ryoken</title>
</head>

<body>

    <!-- NAV BAR-->
    <section id="nav-bar">
        <nav class="navbar  navbar-expand-lg navbar-light">
            <a class="navbar-brand" href="#"><img src="./img/logo.png" class="logo" alt="logo" /></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="navigation">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php?action=10"
                                style="color:rgb(4 137 203) !important;">Ryoken</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                A Propos de nous
                            </a>
                            <div class="dropdown-menu dropdown-menu-right animate slideIn"
                                aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="index.php?action=140">Staff</a>
                                <a class="dropdown-item" href="index.php?action=130">Joueurs Fortnite</a>
                                
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="index.php?action=<?php echo Shop ?>">Shop</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="index.php?action=250">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                    class="bi bi-person-fill" viewBox="0 0 16 16">
                                    <path
                                        d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
                                </svg>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="index.php?action=<?php echo deconnexion ?>">deconnexion</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- END NAV BAR-->
    </section>
    <div id="login">
        <div
            style="text-align:CENTER; color:white !important; font-size:50px; font-family : Courier, monospace; background-color:#1a1e23;border-bottom: 2px solid rgb(4 137 203);">
            Bienvenue <?php echo $_SESSION["PRENOM"] . " ". $_SESSION["NOM"] ?>
        </div>

    </div>
    <?php
?>