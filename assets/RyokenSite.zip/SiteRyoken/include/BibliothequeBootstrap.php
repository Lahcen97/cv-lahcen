<?php 

function formSelectDepuisRecordset($TitreLabel, $name, $id, $recordset, $tabindex, $onchange=null, $selected = null) {

    $code = '<label for="' . $id . '">' . $TitreLabel . '</label>' . "\n";
    if ($onchange==null){
        $code.='<select name="' . $name . '" id="' . $id . '" class="form-control" tabindex="' . $tabindex . '" >';
    }else{
        $code.='<select name="' . $name . '" id="' . $id . '" class="form-control" tabindex="' . $tabindex . '" onchange="'.$onchange.'">';
    }
    $recordset->setFetchMode(PDO::FETCH_NUM);
    $ligne = $recordset->fetch();

    if ($selected == null) {
        while ($ligne) {
            $code .= '<option value="' . $ligne[0] . '">' . $ligne[1] . '</option>' . "\n";
            $ligne = $recordset->fetch();
        }
    } else {
        while ($ligne) {
            $code .= '<option ' . ($ligne[0] == $selected ? 'selected="selected"' :'') . ' value="' . $ligne[0] . '">' . $ligne[1] . '</option>';
            $ligne = $recordset->fetch();
        }     
    }
    $code .= '</select>';
    return $code;
}
?>  