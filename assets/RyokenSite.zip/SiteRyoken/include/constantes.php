<?php


//PAGES BASIQUE
define('Accueil',10);
define('AproposJoueur',130);
define('AproposStaff',140);
define('Message',70);
define('deconnexion',85);



//GESTION NOUVEAUCOMPTE
define('NouveauCompte',150);
define('confirmationMailInscription',151);
define('VerificationCodeConfirmation',152);

// ??? 
define('compte',160);



//DemandeAdherer
define('DemandeAdh',165);
define('Adherer',80);
define('confirmationMail',81);
define('finAdherer',82);


//GESTION SHOP 
define('Shop',20);
define('Panier',25);
define('Livraison',30);
define('Paiement',35);
define('PageArticleSelectione',40);
define('Facture',45);
define('RecapitulatifCommande',50);

//GESTION ARTICLE
define('ListeArticle',210);
define('ModifierArticle',220);
define('AjouterArticle',230);
define('SupprimmerArticle',240);
define('CommandesArticle',240);



//GESTION ADHERENT
define('listeAdherent',95);
define('AjouterAdherent',100);
define('SuprimmerAdherent',110);
define('ModifierAdherent',120);
define('GestionDemande',300);



//GESTION CLIENT
define('listeClient',170);
define('ModifierClient',180);
define('SupprimmerClient',190);
define('CommandesClient',200);
define('parametreClient',250);




?>