<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <script src="./jquery/jquery-3.5.1.min.js"> </script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="./img/Style.css" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <script src="https://www.google.com/recaptcha/api.js"></script>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
    <script src="./js/script.js"></script>
    <title>Ryoken</title>
</head>

<body>

    <!-- NAV BAR-->
<header>
    <section id="nav-bar">
        <nav class="navbar  navbar-expand-lg navbar-light">
            <a class="navbar-brand" href="#"><img src="./img/logo.png" class="logo" alt="logo" /></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="navigation">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php?action=10"
                                style="color:rgb(4 137 203) !important;">Ryoken</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php?action=80">
                               adhérer</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                A Propos de nous
                            </a>
                            <div class="dropdown-menu dropdown-menu-right animate slideIn"
                                aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="index.php?action=140">Staff</a>
                                <a class="dropdown-item" href="index.php?action=130">Joueurs Fortnite</a>
                                <a class="dropdown-item" href="#">Nous contacter</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="index.php?action=20">Shop</a>
                        </li>

                        <li class="nav-item dropdown ">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                S'identifier
                            </a>
                            <div style="width:300px!important; background-color:rgb(218, 218, 218,0.8); padding: 5px 5px 5px 5px;"
                                class="dropdown-menu " aria-labelledby="navbarDropdown">

                                <form action="index.php" id="FrmContact" method="post">
                                    <div class="form-group">
                                        <label for="Identifiant">Identifiant</label>
                                        <input type="Identifiant" class="form-control" name="Identifiant"
                                            id="Identifiant" aria-describedby="identifiantHelp"
                                            placeholder="Entrer l'identifiant">

                                    </div>
                                    <div class="form-group">
                                        <label for="Password">Password</label>
                                        <input name="Password" type="password" class="form-control" id="Password"
                                            placeholder="Password">
                                    </div>
                                    <div class="dropdown-divider"></div>
                                    <input type='submit' value='Valider' name='Valider'></input>

                                    <?php if (isset($alert)){
                                        echo '<script> alert("'.$alert.'") </script>';
                                    } ?>

                                    <p style="padding-left:5px; padding-right:5px ">
                                    </p>
                                </form>
                                <a href="index.php?action=150"><input type="button" value="Créer un compte"></a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- END NAV BAR-->
    </section>
</header>
    <?php
?>