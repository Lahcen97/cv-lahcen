<?php


function SGBDConnect() {
    try {
        $connexion = new PDO('mysql:host=localhost;dbname=ryokenv5', 'root', '');
        $connexion->query('SET NAMES UTF8');
        $connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        echo 'erreur !:' . $e->getMessage() . '<br/>';
        exit();
    }
    return $connexion;
}

function verification($MAIL) {
    $requete = "select CONTACT_MAIL from c_contact where CONTACT_MAIL='".$MAIL."'";
    $resultat = SGBDConnect()->query($requete);
    $count=$resultat->rowCount();
    return $count;
}

function siIdentificationExiste($identif,$mdp){
    $Utilisateur=Array('clients', 'adherent');
    $valide=false;
    for ($i = 0; $i<2 ; $i++) {
        $requete = 'select ID_PSEUDO, MDP from '.$Utilisateur[$i].' where ID_PSEUDO=:identif and MDP=:mdp ';
        $preparation = SGBDConnect()->prepare($requete);
        $preparation->bindParam(':identif',$identif);
        $preparation->bindParam(':mdp',$mdp);
        $preparation->execute();
        $count=$preparation->rowCount();
        if ($count>0){
            $_SESSION['TABLE']=$Utilisateur[$i]; // ca va nous servir à gérer les accessibilité dans le site et pour faire la requete pour créer les sessions
            $valide=True;
        }
    }
    return $valide;      
}


function contact($mail, $nom, $message) {
    if (verification($mail) > 0) {
        $requete = "INSERT INTO M_MESSAGE (CONTACT_MAIL, DATE_HEURE, MESSAGE)  VALUES ('". $mail . "',CURRENT_TIMESTAMP(),'" . $message . "')";
        $resultat = SGBDConnect()->query($requete);
        
    } else {
        $requete = "INSERT INTO c_contact VALUES ('" . $mail . "','" . $nom . "')";
        $resultat = SGBDConnect()->query($requete);
        $requete = "INSERT INTO  M_MESSAGE (CONTACT_MAIL, DATE_HEURE, MESSAGE)  VALUES ('". $mail . "',CURRENT_TIMESTAMP(),'" . $message . "')";
        $resultat = SGBDConnect()->query($requete);
    }
}



function CreerLesSession($identif,$table){
    $requete=' select ID_PSEUDO, NOM, PRENOM from '.$table.' where ID_PSEUDO="'.$identif.'" ';
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_NUM);
    $ligne = $preparation->fetch();
    $_SESSION['IDENTIFIANT'] = $ligne[0];
    $_SESSION['NOM'] = $ligne[1];
    $_SESSION['PRENOM'] = $ligne[2];
}

function verifieSiAdmin($IDENTIF) {
    $requete=' select adherent.STATUT from adherent where adherent.ID_PSEUDO="'.$IDENTIF.'"';
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_NUM);
    $ligne = $preparation->fetch();
    $value=false;
    if ($ligne[0]=="Admin"){
        $value=true;  
    }
    return $value;
}

function AjouterClient($identif,$MDP,$prenom,$nom,$email,$age,$pays){
    $requete="insert into Clients (ID_PSEUDO, MDP, PRENOM, NOM, EMAIL,AGE,PAYS) VALUES ('".$identif."','".$MDP."','".$prenom."','".$nom."','".$email."','".$age."','".$pays."')";
    $preparation = SGBDConnect()->prepare($requete);
    return $preparation->execute();
}

function destruction(){
    session_destroy();
}
    
function GetMessage(){
    $requete=' select m_message.ID_MESSAGE, m_message.DATE_HEURE, c_contact.CONTACT_NOM, m_message.CONTACT_MAIL , m_message.MESSAGE '
            . ' from m_message inner join c_contact on c_contact.CONTACT_MAIL=m_message.CONTACT_MAIL order by m_message.DATE_HEURE desc';
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_NUM);
    $ligne = $preparation->fetch();
    $html="";
    while($ligne){
        $html.='<tr><th> <input type="checkbox" class="checkbox" name="checkbox[]" value="'.$ligne[0].'"  > </th>'
        . '<th scope="row">'.$ligne[1] .'</th>'
        . '<th> '.$ligne[2] .'</th>'
        . '<th>'. $ligne[3].'</th>'
        . '<th> <textarea   style="background:rgb(255,255,255,0); color:white; resize: none;" name="message" class="form-control" id="message"  rows="5"  readonly >'.$ligne[4].'</textarea></th></tr>';
        $ligne = $preparation->fetch();
    }
    return $html;
} 

function countMessage(){
    $requete=' select count(m_message.ID_MESSAGE) from m_message ';
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_NUM);
    $ligne = $preparation->fetch();
    return $ligne[0];
}


function DeleteMessage(){ 
    if(isset($_POST["supprimer"])){  
    foreach($_POST["checkbox"] as $valeur) {
        $requete='DELETE FROM m_message where m_message.ID_MESSAGE=:valeur ';
        $preparation = SGBDConnect()->prepare($requete);
        $preparation->bindParam(':valeur',$valeur);
        $preparation->execute();
    }
    }
}

function listStatut(){
    $requete=' select ADHERENT.STATUT ' 
                .'from adherent ' 
                .'group by ADHERENT.statut';
    $preparation = SGBDConnect()->query($requete);
    return $preparation;
} 

function tableAdherents(){
    $requete=' select adherent.ID_PSEUDO, adherent.NOM, adherent.PRENOM, adherent.AGE, adherent.DESCRIPTION, adherent.STATUT '
             . ' from adherent';
    $preparation = SGBDConnect()->query($requete);
    $ligne = $preparation->fetch();
    $html="";
    while ($ligne){
        $html.= '<tr style="color:white;"><th scope="row">'. $ligne[0] .'</th>'
        . '<th>'. $ligne[1] .'</th>'
        . '<th>'. $ligne[2].'</th>'
        . '<th>'. $ligne[3].'</th>'
        . '<th>  <textarea  style="background:rgb(255,255,255,0); color:white; resize: none;" name="message" class="form-control" id="message"  rows="5"  readonly >'.$ligne[4].'</textarea></th>'
        . '<th>'. $ligne[5].'</th></tr>';
        $ligne = $preparation->fetch();
    }
    return $html; 
}

function ListeAdherentStatut($statut){
    $requete=' select adherent.ID_PSEUDO, concat(adherent.NOM ," ", adherent.PRENOM) from adherent'
             .' where LIBELLE="'.$statut.'"' ;
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_NUM);
    return $preparation;
}

function ListeAdherent(){
    $requete=' select adherent.ID_PSEUDO, concat(adherent.NOM ," ", adherent.PRENOM) from adherent';
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_NUM);
    return $preparation;
}

function SupprimerStatue ($IDENTIFIANT, $STATUE){
    $requete=' DELETE FROM adherent where  STATUT=:statue';
    $sth= SGBDConnect()->prepare($requete);
    return $sth->execute();
}
function AjouterAdherent($statut,$role,$id,$MDP, $prenom, $nom,$description,$age,$twitter,$image){
    $requete="insert into adherent (STATUT,ROLE,ID_PSEUDO,MDP,PRENOM,NOM,DESCRIPTION,AGE,TWITTER,IMAGE) VALUES 
    (:statue,:role,:id,:MDP,:prenom,:nom,:description,:age,:twitter,:image)";
    $preparation = SGBDConnect()->prepare($requete);
    $preparation->bindParam(':statue',$statue);
    $preparation->bindParam(':role',$role);
    $preparation->bindParam(':id',$id);
    $preparation->bindParam(':MDP',$MDP);
    $preparation->bindParam(':prenom',$prenom);
    $preparation->bindParam(':nom',$nom);
    $preparation->bindParam(':description',$description);
    $preparation->bindParam(':age',$age);
    $preparation->bindParam(':twitter',$twitter); 
    $preparation->bindParam(':image',$image);
    $preparation->execute();
}



function GetAdherentsApropos($statue){
    $requete='select adherent.nom, adherent.prenom , adherent.id_pseudo , adherent.age , adherent.role , adherent.description , adherent.twitter, adherent.image '
            .'from adherent ' 
            .'where statut="'.$statue.'"' ;
        $preparation = SGBDConnect()->query($requete);
        $preparation->setFetchMode(PDO::FETCH_NUM);
        $ligne = $preparation->fetch();
        $html="";
        while($ligne){
            $html.=
            '<div class="lespresentations">'
            .'<div class="row">'
            .'<div class="col-lg-4" style="">'
            .'<center><img src="'.$ligne[7].'"> </center>'
            .'<div class="traitVertical"></div>'
            .'</div>'
            .'<div class="col-lg-3" style="width:30%">'
            .'<p class="apropos-detail">'
            .'<b>Nom : '.$ligne[0].' </b><br>'
            .'<b>Prenom : '.$ligne[1].'</b><br>'
            .'<b>Pseudo : '.$ligne[2].'</b><br>'
            .'<b>Age : '.$ligne[3].' ans</b><br>'
            .'<b>role : '.$ligne[4].' </b><br>'
            .'<a id="twitter" target="_blank" rel="noopener noreferrer" href="https://twitter.com/'.$ligne[6].'"><svg
            xmlns="http://www.w3.org/2000/svg" width="40" height="40" class="bi bi-twitter"
            viewBox="0 0 16 16">
            <path
              d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z" />
          </svg></a>'
            .'</p>'
            .'</div>'
            .'<div class="col-lg-5" id="description" style="flex-grow:0; border-left: 2px solid rgb(4,137,203)">'
            .'<p> Description : </p><br>'
            .'<p> '.$ligne[5].' </p>'
            .'</div>'
            .'</div>'
            .'</div>';  
            $ligne = $preparation->fetch();
        }
        return $html;
    }

function SupprimerAdherent($adherent){
    $requete=' DELETE FROM adherent WHERE adherent.ID_PSEUDO= "'.$adherent.'"';
    $sth= SGBDConnect()->prepare($requete);
    return $sth->execute();
}

function GetAdherentInfo($ID=null){
    $requete='select adherent.nom, adherent.prenom , adherent.id_pseudo , adherent.age , adherent.statut, adherent.role, adherent.description , adherent.twitter, adherent.image '
    .'from adherent '
    .' where id_pseudo="'. $ID .'"'; 
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_NUM);
    $ligne = $preparation->fetch();
    return $ligne;
}

function ModifierAdherent ($nom,$prenom,$pseudo,$age,$statut,$role,$description,$twitter){
    $requete="UPDATE ryokenv5.adherent SET adherent.nom='".$nom."' , "
            ."adherent.prenom='".$prenom."' , "
            ."adherent.age='".$age."'  , "
            ."adherent.statut='".$statut."' , "
            ."adherent.role='".$role."' , "
            ."adherent.description='".$description."' , "
            ."adherent.twitter='".$twitter."' "
            ."WHERE id_pseudo='".$pseudo."' " ;         
    $preparation = SGBDConnect()->prepare($requete);
    $preparation->execute();
}

function TableClient (){
    $requete="select ID_PSEUDO as 'pseudo', NOM as 'nom', PRENOM as 'prenom', EMAIL as 'email', ADRESSE as 'adresse' from clients ";
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_ASSOC);
    $ligne = $preparation->fetch();
    $html="";
    while ($ligne){
        $html.= '<tr style="color:white;"><th scope="row">'. $ligne['pseudo'] .'</th>'
        . '<th>'. $ligne['nom'] .'</th>'
        . '<th>'. $ligne['prenom'].'</th>'
        . '<th>'. $ligne['email'].'</th>'
        . '<th>  <textarea  style="background:rgb(255,255,255,0); color:white; resize: none;" name="message" class="form-control" id="message"  rows="5"  readonly >'.$ligne['adresse'].'</textarea></th>';
        $ligne = $preparation->fetch();
    }
    return $html; 
}



function ModifierClient ($nom,$prenom,$pays,$email,$adresse,$age,$pseudo,$mdp=null){
    $requete="UPDATE ryokenv5.clients SET "
            ." clients.nom='".$nom."'  , "
            ." clients.prenom='".$prenom."' , "
            ." clients.pays='".$pays."' , "
            ." clients.email='".$email."' , "
            ." clients.adresse='".$adresse."', "
            ." clients.age='".$age."' ";
    if ($mdp!==null){
        $requete.=", clients.mdp='".$mdp."' ";
    }
    $requete.=" where id_pseudo='".$pseudo."'" ;         
    $preparation = SGBDConnect()->prepare($requete);
    $preparation->execute();

} 

function listClient(){
    $requete="select ID_PSEUDO , concat(NOM,' ',PRENOM) from clients ";
    $preparation = SGBDConnect()->query($requete);
    return $preparation;
}

function SupprimerClient($id){
    $requete='DELETE FROM clients WHERE clients.ID_PSEUDO="'.$id.'"';
    $preparation = SGBDConnect()->prepare($requete);
    $preparation->execute();
}

function InfoClient($id){
    $requete="Select clients.mdp, clients.nom, clients.prenom, clients.pays, clients.email, clients.adresse, clients.age "
            ."from clients "
            ."where clients.id_pseudo='".$id."'";
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_NUM);
    $ligne = $preparation->fetch();
    return $ligne;
}

function ListeDemandeNom(){
    $requete="Select demande.nom,demande.prenom,demande.id_demande from demande";
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_NUM);
    $ligne = $preparation->fetch();
    $html="";
    while($ligne){
        $html.='<th scope="row">'.$ligne[0] .'</th>'
        . '<th scope="row">'.$ligne[0] .'</th>'
        . '<th scope="row">'.$ligne[0] .'</th>'
        . '<th scope="row">'.$ligne[0] .'</th>'
        . '<th> '.$ligne[1] .'</th>'
        . '<th> '.$ligne[2] .'</th>';
        $ligne = $preparation->fetch();
    }
    return $html;
} 

function ListeDemande(){
    $requete="Select demande.id_demande,demande.nom,demande.prenom,demande.age,demande.pseudo,demande.twitter,demande.pourquoinous from demande";
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_NUM);
    $ligne = $preparation->fetch();
    $html="";
    while($ligne){
        $html.='<th scope="row">'.$ligne[0] .'</th>'
        . '<th> '.$ligne[1] .'</th>'
        . '<th> '.$ligne[2] .'</th>'
        . '<th> '.$ligne[3] .'</th>'
        . '<th> '.$ligne[4] .'</th>'
        . '<th> '.$ligne[5] .'</th>'
        . '<th> '.$ligne[6] .'</th>';
        $ligne = $preparation->fetch();
    }
    return $html;
} 

function ajouterdemande($age,$mdp,$nom,$pourquoinous,$prenom,$pseudo,$twitter,$image,$mail){
    $requete="insert into demande (AGE, MDP, NOM, POURQUOINOUS, PRENOM, PSEUDO, TWITTER,IMAGE,EMAIL) VALUES ('". $age . "','" . md5($mdp) . "','" . $nom . "','" . $pourquoinous . "','" . $prenom . "','" . $pseudo . "','" . $twitter . "','" . $image . "','" . $mail . "')";
    $preparation = SGBDConnect()->prepare($requete);
    $preparation->execute();
}

function ListDemandeur(){
    $requete="select ID_DEMANDE, concat(NOM,' ',PRENOM) from demande ";
    $preparation = SGBDConnect()->query($requete);
    return $preparation;
}

function SupprimerDemande($id){
    $requete="DELETE  "
            ." FROM demande "
            ." where demande.ID_DEMANDE=".$id;
    $preparation = SGBDConnect()->query($requete);
    $preparation->execute();;
}

function GetListeArticles(){
    $requete="Select articles.Nom_articles, articles.libelle_categorie, articles.nom_partenaire,"
             . " articles.prixorigine, articles.prixventeunitaire, articles.img_article "
            ."from ARTICLES ";
            $preparation = SGBDConnect()->query($requete);
            $preparation->setFetchMode(PDO::FETCH_NUM);
            $ligne = $preparation->fetch();
            $html="";
            while($ligne){
                $html.= '<tr style="color:white;"><th scope="row">'. $ligne[0] .'</th>'
                . '<th>'. $ligne[1] .'</th>'
                . '<th>'. $ligne[2].'</th>'
                . '<th>'. $ligne[3].'</th>'
                . '<th>  <textarea  style="background:rgb(255,255,255,0); color:white; resize: none;" name="message" class="form-control" id="message"  rows="5"  readonly >'.$ligne[4].'</textarea></th>'
                . '<th><img src="./'. $ligne[5].'" height=100px;></th></tr>';
                $ligne = $preparation->fetch();
            }
            return $html;
}


function ajouterArticle($nomArticle,$CategorieArticle,$nomPartenaire,$PrixArticle,$PrixVenteUnitaire,$description,$imgarticle){
    $requete="insert into articles (nom_articles, libelle_categorie, nom_partenaire, prixorigine, prixventeunitaire, description , img_article) VALUES ('". $nomArticle . "','" . $CategorieArticle . "','" . $nomPartenaire . "','" . $PrixArticle . "','" . $PrixVenteUnitaire . "','" . $description . "','" . $imgarticle . "')";
    $preparation = SGBDConnect()->prepare($requete);
    $preparation->execute();
}

function supprimerArticle($nomarticle){
    $requete='DELETE FROM articles WHERE articles.nom_articles="'.$nomarticle.'"';
    $preparation = SGBDConnect()->prepare($requete);
    $preparation->execute();
}

function modifierArticle($id,$nomArticle,$CategorieArticle,$nomPartenaire,$PrixArticle,$PrixVenteUnitaire,$imgarticle){
    $requete="UPDATE ryokenv5.articles "
    ." SET articles.nom_articles='".$nomArticle."' , "
    ."articles.LIBELLE_CATEGORIE='".$CategorieArticle."' , "
    ."articles.NOM_PARTENAIRE='".$nomPartenaire."'  , "
    ."articles.PRIXORIGINE='".$PrixArticle."' , "
    ."articles.PRIXVENTEUNITAIRE='".$PrixVenteUnitaire."' , "
    ."articles.img_article='".$imgarticle."' "
    ."where articles.nom_articles='".$id."'";        
    $preparation = SGBDConnect()->prepare($requete);
    $preparation->execute();
}

function listArticle(){
    $requete="Select articles.nom_articles from articles";
    $preparation = SGBDConnect()->query($requete);
    return $preparation;
}


function genererArticles($CategorieArticle){
    $requete="Select  articles.img_article, articles.nom_articles,  articles.prixventeunitaire from articles ";
    if ($CategorieArticle!==null){
        $requete.= " where articles.LIBELLE_CATEGORIE='".$CategorieArticle."'";
    }
             
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_NUM);
    $ligne = $preparation->fetch();
    $html='<div class="row justify-content-between  ContenueSupprimerCategorie ">';
    $compteur=0;
    while ($ligne){
        $html.='<div class="col-md-5" style="height:300px; text-align: center; margin-top:15px; border:1px solid #32a1ce;" id="colimg"> '
                .'<a target="_blank" rel="noopener noreferrer" href="http://localhost/site/index.php?action=40&article='.$ligne[1].'">'
                .'<img id="'.$ligne[1].'-shop" src="./'.$ligne[0].'" style="height:75%; margin-top:15px!important;">'
                .'<a target="_blank" rel="noopener noreferrer" href="http://localhost/site/index.php?action=40&article='.$ligne[1].'">'
                .'<p>'.$ligne[1].'<br>'.$ligne[2].' €</p></a>'
                .'</div>';
        $ligne = $preparation->fetch();
        if ($ligne==false){ 
            break;
        }   
        $compteur+=1;
        if ($compteur==2){
            $html.='</div> <div class="row ContenueSupprimerCategorie">';
            $compteur=0;
        }
    }
    $html.="</div> ";
    return $html;
}

function PageArticleSelectionne($nom){
    $requete="Select articles.Nom_articles, articles.libelle_categorie, articles.description, articles.nom_partenaire,"
            . " articles.prixventeunitaire, articles.img_article "
            ."from ARTICLES where Nom_articles='".$nom."'";
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_NUM);
    $ligne = $preparation->fetch();
    $html='<div class="row justify-content-md-center"> '
            .'<div class="col-md-7 ContenueSupprimerCategorie rounded" style=" text-align: center; position:relative; "> '
            .'<img src="./'.$ligne[5].'" style="height:50%; width:50%; margin-top:15px!important;">'
            .'<p style="color:#007bff;">'.$ligne[0].'<br>'.$ligne[4].'€ <br> '.$ligne[2].'<br> </p> '
            .'<form action="index.php?action=20" method="post" onsubmit="return controleIdentification(this);" > '
            .'<input type="hidden" name="NomArticlePanier" value="'.$ligne[0].'"> '
            .'<label for="NombreArticlePanier" style="color:white;"> Nombre d\'article :  </label>'
            .'<input  id="NombreArticlePanier"  name="NombreArticlePanier" type="number" class="form-control" style="width:50%; margin-right: auto; margin-left: auto; " min=1 max=10></input>'
            .'<input type="submit" value="Ajouter dans le panier" class="btn btn-primary " style="margin-top:10px; margin-bottom:10px;" name="AjouterPanier" id="AjouterPanier">'
            .'</input></form></div> </div>';
    return $html;
}



function PagePanierSelectionneRequete($id_client){
    $requete="Select panier.Nom_articles, articles.prixventeunitaire, articles.img_article, panier.NOMBRE_ARTICLES "
            . " from articles inner join panier on articles.Nom_articles=panier.Nom_articles "
            ." where panier.ID_PSEUDO='".$id_client."'";
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_NUM);
    $ligne = $preparation->fetch();
    $count=$preparation->rowCount();
    $html='<div class="row justify-content-between ContenueSupprimerCategorie back"  style="position: relative;">';
    $compteur=0;
    if ( $count>0) {
        while ($ligne){ 
            $html.='<div class="col-md-5 " style="height:550px; text-align: center; margin-top:15px;" id="colimg"> '
                .'<a target="_blank" rel="noopener noreferrer" href="http://localhost/site/index.php?action=40&article='.$ligne[0].'">'
                .'<img src="./'.$ligne[2].'" style="height:75%; width:100%; margin-top:15px!important;" ></a>'
                .'<a target="_blank" rel="noopener noreferrer" href="http://localhost/site/index.php?action=40&article='.$ligne[0].'">'
                .'<p>'.$ligne[0].'<br>'.$ligne[1].' € <br> nombre d\'articles :'.$ligne[3].'</p></a>'
                .'<form action="index.php?action=25" method="post" >'
                .'<input type="hidden" value="'.$ligne[0].'" name="ArticlePanierSuprimmer" >'
                .'<input type="submit" value="Supprimer du Panier" class="btn btn-primary " style="margin:10px 10px 10px 10px;" name="SupprimerPanier">'
                .'</form> '
                . '</div>';
            $ligne = $preparation->fetch();
            if ($ligne==false){ 
                break;
            }   
            $compteur+=1;
            if ($compteur==2){
                $html.='</div> <div class="row ContenueSupprimerCategorie back " style="position: relative;">';
                $compteur=0;
            }
        }
    }else {
        $html.="<h1 style='color:rgb(4,137,203);'> Aucun article n'a été choisit dans le shop</h1>";

    }
    
    $html.="</div> ";
    if ($count>0){
        $html.='<center>
        <input type="submit" value="Confirmer" class="btn btn-primary ContenueSupprimerCategorie"
            style="margin-top:30px; margin-bottom:30px" id="ValiderLivraison" name="ValiderLivraison">
        </input>
    </center>';
    }
    return $html;
}
function SuprimmerPanier($IdClient, $nomArticles){
    $requete='DELETE FROM panier WHERE panier.nom_articles="'.$nomArticles.'" and panier.ID_PSEUDO="'.$IdClient.'"';
    $preparation = SGBDConnect()->prepare($requete);
    $preparation->execute();
}

function AjouterPanier($NomArticle, $idClient,$NombreArticle){
    $requete="insert into panier values ('".$idClient."','".$NomArticle."','".$NombreArticle."')";
    $preparation = SGBDConnect()->prepare($requete);
    $preparation->execute();
}



function GenererCategorie($famille){
    $requete="Select categories.LIBELLE_CATEGORIE  "
            ."from categories where FAMILLE_CATEGORIE='".$famille."'" ;
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_NUM);
    $ligne = $preparation->fetch();
    $html="";
    while ($ligne) { 
        $html.='<li class="nav-item"><a class="nav-link navbarVerticaleSousCategorie CategoriClick" id="'.$ligne[0].'" href="#">'.$ligne[0].'</a></li>';
        $ligne = $preparation->fetch();
    }
    return $html;
}

function listCat(){
    $requete=' select Categories.Libelle_categorie ' 
                .'from categories ' 
                .'group by categories.libelle_categorie';
    $preparation = SGBDConnect()->query($requete);
    return $preparation;
} 

function PrixTotalCommande($idclient){
    $requete='Select SUM(articles.prixventeunitaire*Panier.nombre_articles) as PrixTotalSansLivraison ' 
    .'from panier inner join articles '
    .'on panier.nom_articles=articles.nom_articles '
    .'where panier.ID_PSEUDO="'.$idclient.'"';
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_NUM);
    $ligne = $preparation->fetch();
    $html='<td colspan="3">'.$ligne[0].'€</td>';
    return $html;
}

function FactureArticles($id_client){
    $requete="Select panier.Nom_articles,articles.img_article, panier.nombre_articles, articles.prixventeunitaire , articles.prixventeunitaire*panier.nombre_articles as PrixTotalParArticle "
            . " from articles inner join panier on articles.Nom_articles=panier.Nom_articles "
            ." where panier.ID_PSEUDO='".$id_client."'";
    $preparation = SGBDConnect()->query($requete);
    $preparation->setFetchMode(PDO::FETCH_NUM);
    $ligne = $preparation->fetch();
    $html="";
    while ($ligne) { 
        $html.='<tr>'
        .'<th scope="row"><img src="./'.$ligne[1].'" style="max-height:60px">'.$ligne[0].'</img></th>'
        .'<td>x'.$ligne[2].'</td>'
        .'<td>'.$ligne[3].'€</td>'
        .'<td>'.$ligne[4].'€</td>'
        .'</tr>';
        $ligne = $preparation->fetch();
    }
    return $html;
}

function  AjouterLivraison ($nomprenom,$adresse,$pseudo,$numPortable){
    $requete="insert into ryokenv5.commande (NOM_PRENOM_LIVRAISON,adresselivraison,date_commande,id_pseudo, NUMERO_PORTABLE) "
             ."VALUES ('". $nomprenom . "','". $adresse ."',CURRENT_TIMESTAMP(),'".$pseudo."','".$numPortable."')";      
    $preparation = SGBDConnect()->prepare($requete);
    $preparation->execute();
} 

function genererChaineAleatoire($longueur)
    {
        $caracteres = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $longueurMax = strlen($caracteres);
        $chaineAleatoire = '';
        for ($i = 0; $i < $longueur; $i++)
        {
            $chaineAleatoire .= $caracteres[rand(0, $longueurMax - 1)];
        }
        return $chaineAleatoire;
    }


function articleDejaExistant($article,$pseudo){
    $requete='Select panier.NOM_ARTICLES ' 
    .'from panier '
    .'where panier.ID_PSEUDO="'.$pseudo.'" and panier.NOM_ARTICLES="'.$article.'" ';
    $resultat = SGBDConnect()->query($requete);
    $count=$resultat->rowCount();
    return $count;
}

Function VerificationPseudoDemandeAdhererSiValable($pseudo){
    $requete="select demande.PSEUDO from demande where demande.PSEUDO='".$pseudo."'";
    $resultat = SGBDConnect()->query($requete);
    $count=$resultat->rowCount();
    return $count;
}