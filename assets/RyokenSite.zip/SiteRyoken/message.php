<?php
echo DeleteMessage();

if (isset($_SESSION["IDENTIFIANT"])) {
    require_once './include/enteteAdmin.php';
} else {
    header("location: index.php?action=10");
    exit();
}
?>
<div class="container" style="margin-top:30px; ">
    <form method="post" action="index.php?action=70">
        <table class="table border " style="background:rgba(97, 97, 97, 0.329)"> 
            <thead style="color:black; width:100px; ">
                <tr>
                    <th scope="col"> <a id="select-all" class="select-all"> Tout supprimer</a></th>
                    <th scope="col">Heures</th>
                    <th scope="col">Noms</th>
                    <th scope="col">Mails</th>
                    <th scope="col">Messages</th>
                </tr>
            </thead>

            <tbody style="color:white;">
                <?php
                echo getMessage();
                ?>
                <tr>
                    <?php 
                if (($_SESSION['STATUT'])=='Admin'){
                   echo '<th><input type="submit" style="background:rgb(4 137 203); color:white; border: 2px solid white;" name="supprimer" value="supprimer"></th>'; 
                   
                }else{
                    echo '<th> </th>';
                }?>

                    <th></th>
                    <th></th>
                    <td></td>
                    <td><?php echo 'Nombre de messages: (' . countMessage() . ')'; ?></td>
                </tr>
            </tbody>
        </table>
    </form>
    <script>

    </script>
</div>
</body>

</html>