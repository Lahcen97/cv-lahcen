<?php

require_once './include/entete.php'; // gestion de l'affichage pour les personnes deconnectées.
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

switch ($_REQUEST['action'])
{
case Adherer:
?>

<div
    style="text-align:CENTER; color:white !important; font-size:50px; font-family : Courier, monospace; background-color:#1a1e23;border-bottom: 2px solid rgb(4 137 203);">
    Voulez-vous rejoindre l'équipe Ryoken ?
</div>
<div class="container rounded" style="background:rgba(97, 97, 97, 0.329); margin-bottom:100px; color:white; padding-top: 3%; padding-bottom: 3%; margin-bottom: 5%; margin-top: 5%;">
    <form action="index.php?action=<?php echo confirmationMail?>" method="post" enctype="multipart/form-data"
        onsubmit="return controleFrmAdherer(this); ">
        <div class="row justify-content-between">


            <?php if (!isset($_SESSION["PseudoDemande"])){
    ?>

            <div class="col-md-5">
                <label for="prenomDemande"> Saisissez votre prenom : </label>
                <input id="prenomDemande" name="prenomDemande" type='text' class="form-control" required></input>

                <label for="NomDemande">Saisissez votre nom : </label>
                <input id="NomDemande" name="NomDemande" type='text' class="form-control" required></input>

                <label for="AgeDemande">Saisissez votre age : </label>
                <input id="AgeDemande" name="AgeDemande" type='number' class="form-control" min=15 max=70
                    value="15"></input>

                <label for="roleDemande">Pourquoi voulez-vous nous rejoindre ? </label>
                <textarea id="roleDemande" name="roleDemande" class="form-control"
                    placeholder="Exprimez-vous en quelques lignes." rows="5" maxlength="1000" minlength="50"
                    style="margin-bottom:10px" required></textarea>
            </div>
            <div class="col-md-5">
                <label for="twitterDemande">Saissez le lien de votre compte twitter : </label>
                <input id="twitterDemande" name="twitterDemande" type='text' maxlength="1000" class="form-control"
                    required></input>

                <label for="emailDemande">Saisissez votre mail : </label>
                <input id="emailDemande" name="emailDemande" type="email" class="form-control" required></input>

                <label for="PseudoDemande">Saisissez votre pseudo : </label>
                <input id="PseudoDemande" name="PseudoDemande" type='text' class="form-control" maxlength="32"
                    minlength="7" required></input>

                <label for="mdpDemande">Saisissez votre mot de passe : </label>
                <input id="mdpDemande" name="mdpDemande" type='password' class="form-control" minlength="7"
                    required></input>

                <label for="mdpDemande2">Saisissez une deuxième fois votre mot de passe : </label>
                <input id="mdpDemande2" name="mdpDemande2" type='password' class="form-control" minlength="7"
                    required></input>

                <label for="file"> Photo profil: </label>
                <input type="file" id="file" name="file" style="color:white!important; margin-top:10px"
                    accept="image/png, image/jpeg" required> <br>
                    <div class="g-recaptcha" data-sitekey="6LeQ6VQaAAAAAKopIiJ0bA0XfFBUpq79mWlCfDfo"></div>
                <input type='submit' value='Soumettre' class="btn btn-primary"
                    style="margin-top:10px; margin-bottom:10px" name="submitDemande">
                </input>
            </div>

            <?php } else if (isset($_SESSION["PseudoDemande"])){?>

            <div class="col-md-5">
                <label for="prenomDemande"> Saisissez votre prenom : </label>
                <input id="prenomDemande" name="prenomDemande" type='text' class="form-control"
                    value="<?php echo $_SESSION["prenomDemande"]?>" required></input>

                <label for="NomDemande">Saisissez votre nom : </label>
                <input id="NomDemande" name="NomDemande" type='text' class="form-control"
                    value="<?php echo $_SESSION["NomDemande"]?>" required></input>

                <label for="AgeDemande">Saisissez votre age : </label>
                <input id="AgeDemande" name="AgeDemande" type='number' class="form-control"
                    value="<?php echo $_SESSION["AgeDemande"]?>" min=15 max=70 value="15"></input>

                <label for="roleDemande">Pourquoi voulez-vous nous rejoindre ? </label>
                <textarea id="roleDemande" name="roleDemande" class="form-control"
                    value="<?php echo $_SESSION["roleDemande"]?>" rows="5" maxlength="1000" minlength="50"
                    style="margin-bottom:10px" required><?php echo $_SESSION["roleDemande"] ?></textarea>
            </div>
            <div class="col-md-5">
                <label for="twitterDemande">Saissez votre lien de votre compte twitter : </label>
                <input id="twitterDemande" name="twitterDemande" type='text' maxlength="1000" class="form-control"
                    value="<?php echo $_SESSION["twitterDemande"]?>" required></input>

                <label for="emailDemande">Saisissez votre mail : </label>
                <input id="emailDemande" name="emailDemande" type="email" class="form-control"
                    value="<?php echo $_SESSION["emailDemande"]?>" required></input>

                <label for="PseudoDemande">Saisissez votre pseudo : </label>
                <input id="PseudoDemande" name="PseudoDemande" type='text' class="form-control"
                    value="<?php echo $_SESSION["PseudoDemande"]?>" maxlength="32" minlength="7" required></input>

                <label for="mdpDemande">Saisissez votre mot de passe : </label>
                <input id="mdpDemande" name="mdpDemande" type='password' class="form-control" minlength="7"
                    required></input>

                <label for="mdpDemande2">Saisissez une deuxième fois votre mot de passe : </label>
                <input id="mdpDemande2" name="mdpDemande2" type='password' class="form-control" minlength="7"
                    required></input>

                <label for="file"> Votre de  profil: </label>
                <input type="file" id="file" name="file" style="color:white!important; margin-top:10px"
                    accept="image/png, image/jpeg"></input> <br> 
                    <div class="g-recaptcha" data-sitekey="6LeQ6VQaAAAAAKopIiJ0bA0XfFBUpq79mWlCfDfo"></div>
                <input type='submit' value='Soumettre' class="btn btn-primary"
                    style="margin-top:10px; margin-bottom:10px" name="submitDemande">
                </input>
            </div>
            <?php }?>
        </div>

    </form>
</div>
<?php 
break;

case confirmationMail:
    require './PHPMailer/src/Exception.php';
    require './PHPMailer/src/PHPMailer.php';
    require './PHPMailer/src/SMTP.php';
if (isset($_POST["submitDemande"]) && isset($_POST['g-recaptcha-response'])){
    require('recaptcha-master/autoload.php');
    $recaptcha = new \ReCaptcha\ReCaptcha('6LeQ6VQaAAAAACb_3g6ge01w7f4mAWzK2ycVF_UQ');
    $resp = $recaptcha->verify($_POST['g-recaptcha-response']); 
    if ($resp->isSuccess()) {
    $_SESSION["NomDemande"]=$_POST["NomDemande"];
    $_SESSION["prenomDemande"]=$_POST["prenomDemande"];
    $_SESSION["AgeDemande"]=$_POST["AgeDemande"];
    $_SESSION["roleDemande"]=$_POST["roleDemande"];
    $_SESSION["twitterDemande"]=$_POST["twitterDemande"];
    $_SESSION["PseudoDemande"]=$_POST["PseudoDemande"];
    $_SESSION["mdpDemande"]=$_POST["mdpDemande"];
    $_SESSION["emailDemande"]=$_POST["emailDemande"];
    $pseudo=$_POST["PseudoDemande"]; // verifier si pseudo existe
  if (VerificationPseudoDemandeAdhererSiValable($pseudo)!==0){
    echo "<script> alert('Le pseudo est déjà utilisé par un demandeur ou un adhérent, veuillez choisir un autre.')</script>";
    echo "<script type='text/javascript'> document.location.replace('index.php?action=80');</script>";
    exit();
  }


  // controle de l'image 
  $file=$_FILES["file"];
  $fileName=$_FILES["file"]["name"]; 
  $fileTmpName=$_FILES["file"]["tmp_name"]; // localisation temporaire du fichier.
  $fileSize=$_FILES["file"]["size"];
  $fileError=$_FILES["file"]["error"];
  $fileType=$_FILES["file"]["type"];
  
  $fileSplit=explode('.',$fileName);
  $fileExtension=strtolower(end($fileSplit)); // recupérer l'extension du fichier.

  if($fileError===0){
    if ($fileSize<1000000){
      $unique_name = uniqid('',true). '.' . $fileExtension; // donner un nom unique au fichier
      $FileDestination=$unique_name;
      $_SESSION["ImageDemande"]=$FileDestination;
      move_uploaded_file($fileTmpName, $FileDestination); // envoyer le fichier
    }
    else{
      echo "<script> alert('Choisisssez une image inferieur à 10 megabits.')</script>";
      echo "<script type='text/javascript'> document.location.replace('index.php?action=80');</script>";
      exit();
    }
  }
  else{
    echo "<script> alert('Une erreur est survenue lors du téléchargment du fichier..')</script>";
    echo "<script type='text/javascript'> document.location.replace('index.php?action=80');</script>";
    exit();
  }
    } else {
        echo "<script> alert('Le captacha est invalide.')</script>";
        echo "<script type='text/javascript'> document.location.replace('index.php?action=80');</script>";
    }
}




// Envoyer le mail avec le code de confirmation
$adresseMail=$_SESSION["emailDemande"];
$objet="Confirmation inscription Ryoken";
$name=$_SESSION["NomDemande"];
$_SESSION["CodeVerificationDemande"]=mt_rand (10000,99999);
$message="Bonjour ".$name.", <br> votre code  de confirmation est  :" .$_SESSION["CodeVerificationDemande"].".<br> Cordialement, <br> -L'equipe Ryoken. <br> <center> <img src='https://pbs.twimg.com/profile_images/1348343673939963904/65yHDRre.png'></center>";
$key="c86e0d7c45ca4b0ae07055e4687f4dc0";

$mail = new PHPMailer();  // Cree un nouvel objet PHPMailer
//$mail->IsSMTP(); // active SMTP
$mail->IsHTML(true);
$mail->SMTPDebug = 0;  // debogage: 1 = Erreurs et messages, 2 = messages seulement
$mail->SMTPAuth = true;  // Authentification SMTP active
$mail->SMTPSecure = 'ssl'; // Gmail REQUIERT Le transfert securise
$mail->Host = 'smtp.gmail.com';
$mail->Port = 465;
$mail->Username = 'ryoken.esport2021@gmail.com';
$mail->Password = md5($key);
$mail->SetFrom('ryoken.esport2021@gmail.com', 'Ryoken');
$mail->Subject = $objet;
$mail->Body = $message;
$mail->AddAddress($adresseMail);
if(!$mail->Send()) {
  echo 'Mail error: '.$mail->ErrorInfo;
} 

?>
<div class="container">
    <div class="row">
        <div class="col-md-12 rounded" style="margin-top:100px;margin-bottom:100px; background:rgb(218, 218, 218,0.4)">
            <center>
                <div class="ContenueDemandeAdherer">

                    <h3 style="color:white;"> Un code de verification a été envoyé a votre mail <b
                            style='color:rgb(4,137,203)'> <?php echo  $adresseMail  ?> </b></h3>
                    <form action="index.php?action=<?php echo finAdherer; ?>" method="post">
                        <label for="CodeVerificationDemande">Saisissez le code de verification : </label>
                        <input type='text' id="CodeDemande" name="CodeDemande" class="form-control" minlength="5"
                            maxlength="5" style="width:50%;" required></input>
                        <input type='submit' value='Soumettre' class="btn btn-primary"
                            style="margin-top:10px; margin-bottom:10px" name="submitDemandeCodeVerfication"
                            id="submitDemandeCodeVerfication">
                        </input>
                    </form>
                </div>
            </center>
        </div>
    </div>
</div>
<?php
break;

case finAdherer:

    if  (isset($_POST["submitDemandeCodeVerfication"]) && $_POST["CodeDemande"]==$_SESSION["CodeVerificationDemande"]){
        $nom=$_SESSION["NomDemande"];
        $prenom=$_SESSION["prenomDemande"];
        $age=$_SESSION["AgeDemande"];
        $pourquoinous=$_SESSION["roleDemande"];
        $twitter=$_SESSION["twitterDemande"];
        $pseudo=$_SESSION["PseudoDemande"];
        $mdp=$_SESSION["mdpDemande"];
        $mail=$_SESSION["emailDemande"];
        $image=$_SESSION["ImageDemande"];
        echo ajouterdemande($age,$mdp,$nom,$pourquoinous,$prenom,$pseudo,$twitter,$image,$mail);
        session_destroy(); // si le code de verification est correct, on rajoute le demandeur dans la BD et on supprime les sessions. 
        ?>
<div class="container">
    <center>
        <div class="rounded"    
            style="margin-top:100px; margin-bottom:100px; background:rgb(218, 218, 218,0.4); color:white; width:60%; height:50Vh;">
            <p> La demande d'adhésion a bien été prise en compte.
                <br> Vous receverez une réponse via twitter ou votre mail prochainement <br>
                Si la demande est acceptée, vous pourrez vous connecter avec vos identifiants que vous allez
                recevoir
                après le traitement de la demande d'adhésion par mail.
                <br> L'équipe Ryoken vous remercie pour votre intérêt.
            </p>
            <div>
    </center>
</div>
<?php
    }
    else if (isset($_POST["submitDemandeCodeVerfication"])  && $_POST["CodeDemande"]!==$_SESSION["CodeVerificationDemande"]) {
        ?>

<div class="container ">
    <center>
        <div class="rounded"
            style="margin-top:100px; margin-bottom:100px; background:rgb(218, 218, 218,0.4);  color:white; width:80%; height:50Vh;">
            <h3 style="margin-top:15px; margin-bottom:15px;"> le code de vérification est incorrecte. Veuillez ressayez à nouveau en cliquant ici.<br>
            </h3>
            <form action="index.php?action=81" method="post">
                <input type='submit' value='Renvoyez le code' class='btn btn-primary'
                    style='margin-top:10px; margin-bottom:10px' name='IncorrectCodeVerificationAdhrerer'
                    id='IncorrectCodeVerificationAdhrerer'>
                </input>
            </form>
        <div>
    </center>
</div>


<?php
    }else { 
    echo "<script type='text/javascript'> document.location.replace('index.php?action=80');</script>";
    exit(); 
    }
    break;
}


require_once './include/pied.php'
?>