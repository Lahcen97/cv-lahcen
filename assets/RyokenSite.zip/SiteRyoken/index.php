<?php
session_start();
require_once './include/constantes.php';
require_once './include/bdd.php';
require_once './include/BibliothequeBootstrap.php';


if (isset($_POST["Valider"])){
    $identif=$_POST["Identifiant"];
    $mdp=$_POST["Password"];
    
    if (siIdentificationExiste($identif,md5($mdp))==TRUE){
        echo CreerLesSession($identif,$_SESSION['TABLE']); 
        if (verifieSiAdmin($identif)==true && $_SESSION['TABLE']=="adherent"){
            $_SESSION['STATUT']="Admin";
        }

        if (verifieSiAdmin($identif)==false && $_SESSION['TABLE']=="adherent"){
            $_SESSION['STATUT']="Utilisateur";
        }
        
        if ($_SESSION['TABLE']=="clients"){
            $_SESSION['STATUT']="Clients";
        }

        header("index.php?action=10");  
    }
    else { 
        $alert='Votre indentifiant et/ou  mot de passe, est/sont incorrect(s).';
      }
    }


if (!isset($_REQUEST['action']))
{ // Démarrage de l'application.
$_REQUEST['action'] = Accueil;
}

if (isset($_POST["submit"]) && isset($_POST['g-recaptcha-response'])){
    require('recaptcha-master/autoload.php');
    $recaptcha = new \ReCaptcha\ReCaptcha('6LeQ6VQaAAAAACb_3g6ge01w7f4mAWzK2ycVF_UQ');
    $resp = $recaptcha->verify($_POST['g-recaptcha-response']); 

    if ($resp->isSuccess()) {
        $mail=$_POST["email"];
        $nom=$_POST["nom"];
        $message=$_POST["message"];
        echo contact($mail,$nom,$message); 
    }
    else {
        echo "<script> alert('Le captacha est invalide.')</script>";
    }
}


switch ($_REQUEST['action'])
{
case Accueil:
    require_once './Accueil.php';
    break;


// les demande pour adhérer sont traiter dans les trois cases suivantes :
case Adherer: 
    require_once './adherer.php';
    break;
case confirmationMail:
    require_once './adherer.php';
    break;
case finAdherer:
    require_once './adherer.php';
    break;


//Création de compte par les clients 
case NouveauCompte:
    require_once './NouveauCompte.php';
    break;
case confirmationMailInscription:
    require_once "./NouveauCompte.php";
    break;
case VerificationCodeConfirmation:
    require_once "./NouveauCompte.php";
    break;



// Une fois l'admin rajoute un adhérent (via l'onglet ajouter adhérent), il s'affiche directement dans l'une de ces pages
// en fonction de son statue.
case AproposStaff:
    require_once './aproposStaff.php';
    break;
case AproposJoueur:
    require_once './aproposStaff.php';
    break;

// recevoir les messages qui ont été envoyés sur la partie nous contacter de la page,
// les adhérents peuvent consulter les messages.
// Que les adhérents admin peuvent supprimer un ou plusieurs messages à la fois. 
case Message:
    require_once './message.php';
    break;

case AjouterAdherent:
    require_once './gestionAdherents.php';
    break;


// gérer les adhérents de l'assocation.
case SuprimmerAdherent:
    require_once './gestionAdherents.php';
    break;

case ModifierAdherent:
    require_once './gestionAdherents.php';
    break;

case listeAdherent:
    require_once './gestionAdherents.php';
    break;
case GestionDemande:
    require_once './gestionAdherents.php';
    break;



//Shop
case Shop:
    require_once './shop.php';
    break;
case Panier:
    require_once './shop.php';
    break;
  
case Livraison:
    require_once './shop.php';
    break;
case Paiement:
    require_once './shop.php';
    break;
case PageArticleSelectione:
    require_once './shop.php';
    break;
case Facture:
    require_once './shop.php';
    break;
case RecapitulatifCommande:
    require_once './shop.php';
    break;
//Gérer les clients et leurs commandes  ( pages gérée par les admins )
case listeClient:
    require_once './gestionClients.php';
    break;
case ModifierClient:
    require_once './gestionClients.php';
    break;
case SupprimmerClient:
    require_once './gestionClients.php';
    break;
case CommandesClient:
    require_once './gestionClients.php';
    break;
case parametreClient:
    require_once './parametreClient.php';
    break;

//Gérer les articles ( pages gérée par les admins )
case ListeArticle:
    require_once './gestionArticles.php';
    break;
case ModifierArticle:
    require_once './gestionArticles.php';
    break;
case SupprimmerArticle:
    require_once './gestionArticles.php';
    break;
case AjouterArticle:
    require_once './gestionArticles.php';
    break;

case deconnexion:
session_destroy();
header("location: index.php?action=" . Accueil); 
exit();
}