//control functions
function controleFrmContact(FrmContact)
{
    var valide = false;

    if (!estUneChaineValide(FrmContact.elements["nom"].value))
    {
        alert("Le nom n'est pas valide !");
        valide = false;
    }
    else {
        valide=true;
    }
    return valide;    
}

function controleFrmAdherer(FrmDemandeAdherer){
  var valide = false;

  if (!estUneChaineValide(FrmDemandeAdherer.elements["prenomDemande"].value)){
    alert("Le prenom n'est pas valide !");
    valide = false;
  }
  if (!estUneChaineValide(FrmDemandeAdherer.elements["NomDemande"].value)){
    alert("Le nom n'est pas valide !");
    valide = false;
  }
  if (!estUnMotDePasseValide(FrmDemandeAdherer.elements["mdpDemande"].value)){
    alert("Le mot de passe doit être un mélange de majuscules, chiffre et caractères spéciaux ");
    valide = false;
  }
  if (FrmDemandeAdherer.elements["mdpDemande"].value!=FrmDemandeAdherer.elements["mdpDemande2"].value){
    alert("Les mots de passe ne sont pas identiques !");
    valide=false;
  }else{

    valide=true;
  }
  return valide; 
}



function controleFrmInscription(FrmDemandeInscription){
  var valide = false;

  if (!estUneChaineValide(FrmDemandeInscription.elements["nom"].value))
  {
      alert("Le nom n'est pas valide !");
      valide = false;
  }
  else {
      valide=true;
  }
  return valide; 
}


function controleIdentification(){
  if(document.getElementById("connexion").value=="null"){ // Quand c'est null , on exige à l'utilisateur une authentification  pour qu'il puisse  ajouter des articles dans son panier.
    return false;
  }else{
    return true;
  }
}

function estUnMotDePasseValide(motDepasse){
  PointsDifficulte=0;
  jeu ='!,%&@#$^*?_~-';
  taille=motDepasse.length;
  maj=null; // maj, chiffre, charactereSpecial  vont prendre une valeur (1) 
  chiffre=null;// lorsqu'une majuscule, un chiffre ou un caractère spécial existe dans le mot de passe afin de le rendre plus difficile.
  caractereSpecial=null; // la valeur de ces trois variable serons ajouter à  la variable PointsDifficulte qui doit être supérieur à 2 pour avoir un mot de passe moyen.
  for (var i = 0; i < taille; i++){
    leChar = motDepasse.charAt(i);
    if (caractereSpecial==null){
      for (var j = 0; j < jeu.length;j++){
          LeCharSpecial=jeu.charAt(j);
          if (LeCharSpecial==leChar){
            caractereSpecial=1;
          break;
        }
      }
    }
    if (leChar>='A' && leChar<='Z' && maj===null){
      maj=1;
    }

    if (leChar>='0' && leChar<='9' && chiffre==null){
      chiffre=1;
    }
    PointsDifficulte=caractereSpecial+maj+chiffre;
    if (PointsDifficulte==3){
      break;
    }
  }
  if (taille > 7) { // la taille du mot de passe doit être supérieur à 7. 
    PointsDifficulte+=1;
  }
  if (PointsDifficulte<2){
    return false;
  }else{
    return true;
  }
}

function estUneChaineValide(chaineCaracteres){
    chaineCaracteres = chaineCaracteres.toLowerCase().trim();
    var jeu = 'ÿüûùœôïîëêèéçæâà-';
    valide = false,
    leChar = '';
    for (var i = 0; i < chaineCaracteres.length; i++)
    {
        leChar = chaineCaracteres.charAt(i);

        if (!((leChar >= 'a' && leChar <= 'z') || jeu.indexOf(leChar) >= 0))
        {
            valide = false;
        }
        else
        {
            valide = true;
        }
    }
    return valide;
}



$( document ).ready(function() {
  $("#select-all").click(function() {
    if ($('.checkbox').is(':checked')){
      $('.checkbox').prop('checked', false);
    }
    else{
      $('.checkbox').prop('checked', true);
    }
  });
  $("#maillot").mouseover(function(){
    $(this).attr("src", "./img/maillot_ryoken_dos.png");  
  });
  $("#sweat").mouseover(function(){
    $(this).attr("src", "./img/sweat_ryoken_dos.png");  
  });
  
  $("#maillot").mouseout(function(){
    $(this).attr("src", "./img/maillot_ryokenv2.png");
  });
  $("#sweat").mouseout(function(){
    $(this).attr("src", "./img/sweat_ryoken.png");
  });

  $("#ListeAdherentModifier").change(function(){
    $.ajax({
      type: "POST",
      url: "./AJAX/adherent.php", //ou ce que tu veux pour accéder au fichier
      data: "adherent=" + $("#ListeAdherentModifier").val(),
      success: function(data) {
          donnees = JSON.parse(data);
          $("#RôleAdh").val(donnees['role']);
          $("#prodId").val(donnees['pseudo']);
          $("#MdpAdh").val(donnees['mdp']);
          $("#NomAdh").val(donnees['nom']);
          $("#PrenomAdh").val(donnees['prenom']);
          $("#AgeAdh").val(donnees['age']);
          $("#TwitterAdh").val(donnees['twitter']);
          $("#ListeStatutModifier").val(donnees['statut']);
          $("#DescriptionAdh").val(donnees['description']);
      } }); });


  $("#ListeClientModifier").change(function(){
    $.ajax({
      type: "POST",
      url: "./AJAX/client.php", //ou ce que tu veux pour accéder au fichier
      data: "client=" + $("#ListeClientModifier").val(),
      success: function(data) {
          donnees = JSON.parse(data);
          $("#NomClientModifier").val(donnees['nom']);
          $("#PrenomClientModifier").val(donnees['prenom']);
          $("#AgeClientModifier").val(donnees['age']);
          $("#EmailClientModifier").val(donnees['email']);
          $("#PaysClientModifier").val(donnees['pays']);
          $("#AdresseClientModifier").val(donnees['adresse']);          
      } }); });
  
  $("#listeDemande").change(function(){
    $.ajax({
      type: "POST",
      url: "./AJAX/demande.php", //ou ce que tu veux pour accéder au fichier
      data: "demande=" + $("#listeDemande").val(),
      success: function(data) {
          donnees = JSON.parse(data);
          $("#NomDemande").val(donnees['nom']);
          $("#PrenomDemande").val(donnees['prenom']);
          $("#AgeDemande").val(donnees['age']);
          $("#PseudoDemande").val(donnees['pseudo']);
          $("#mdpDemande").val(donnees['mdp']);
          $("#PourquoiNousDemande").val(donnees['pourquoinous']);
          $("#PhotoDemande").attr("src", './img/'+ donnees['image']);
          $("#TwitterDemande").val(donnees['twitter']);
          $("#imgDemande").val("./img/"+donnees['image']);
      } }); });

  $("#ListeArticlesModifier").change(function(){
    $.ajax({
      type: "POST",
      url: "./AJAX/article.php", //ou ce que tu veux pour accéder au fichier
      data: "article=" + $("#ListeArticlesModifier").val(),
      success: function(data) {
          donnees = JSON.parse(data);
          $("#NomArticlesModifier").val(donnees['NomArticle']);
          $("#CategorieArticleModifier").val(donnees['CategorieArticle']);
          $("#NomPartenaireModifier").val(donnees['NomPartenaire']);
          $("#PrixOrigineModifier").val(donnees['PrixOrigine']);
          $("#PrixVenteUnitaireModifier").val(donnees['PrixVenteUnitaire']);
          $("#ImageArticleModifier").attr("src", donnees['ImageArticle']);       
      } }); });
  
  $(".CategoriClick").click(function(){ 
      $.ajax({
        type: "POST",
        url: "./AJAX/categorieShop.php", 
        data: "libelleCategorie=" + $(this).text(),
        success: function(data) {
            donnees =  JSON.parse(data);
            $(".ContenueSupprimerCategorie").remove();
            $(".appendCategorie").append(donnees);
        } }); });
        


  
  $("#ValiderLivraison").click(function(){
   
      $("#formulaireLivraison").removeAttr("hidden");
      $([document.documentElement, document.body]).animate({scrollTop: $("#formulaireLivraison").offset().top}, 500);  
    });
  
  $("#AjouterPanier").click(function(){
    $.ajax({
      type: "POST",
      url: "./AJAX/PanierDemandeInscription.php", //ou ce que tu veux pour accéder au fichier
      success: function(data) {
          donnees =  JSON.parse(data);
          $(".ContenueSupprimerCategorie").append(donnees);
          window.scrollTo(0,document.body.scrollHeight);
      } });

  });
} );


function writeCookie(name,value,days) {
  var date, expires;
  if (days) {
      date = new Date();
      date.setTime(date.getTime()+(days*24*60*60*1000));
      expires = "; expires=" + date.toGMTString();
          }else{
      expires = "";
  }
  document.cookie = name + "=" + value + expires + "; path=/";
}

function readCookie(name) {
  var i, c, ca, nameEQ = name + "=";
  ca = document.cookie.split(';');
  for(i=0;i < ca.length;i++) {
      c = ca[i];
      while (c.charAt(0)==' ') {
          c = c.substring(1,c.length);
      }
      if (c.indexOf(nameEQ) == 0) {
          return c.substring(nameEQ.length,c.length);
      }
  }
  return '';
}
