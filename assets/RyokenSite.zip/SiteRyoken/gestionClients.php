<?php
if (isset($_SESSION["IDENTIFIANT"])) {
    require_once './include/enteteAdmin.php';
} else {
    header("location: index.php?action=10");
    exit();
}

switch ($_REQUEST['action']){
case listeClient:  
?>
<div class="container">
    <table class="table border border-primary" style="margin-top:30px;  ">
        <thead style="color:grey; width:100px;  ">
            <tr>
                <th scope="col">Identifiant</th>
                <th scope="col">Nom</th>
                <th scope="col">Prenom</th>
                <th scope="col">Email</th>
                <th scope="col">Adresse</th>
            </tr>
        </thead>
        <?php
    echo TableClient();
?>
    </table>
</div>
<?php
    break;
case ModifierClient:
    if (isset($_POST['ClientModifier'])){
        $id=$_POST['ListeClientModifier'];
        $nom=$_POST['NomClientModifier'];
        $prenom=$_POST['PrenomClientModifier'];
        $age=$_POST['AgeClientModifier'];
        $email=$_POST['EmailClientModifier'];
        $pays=$_POST['PaysClientModifier'];
        $adresse=$_POST['AdresseClientModifier'];
        echo ModifierClient ($nom,$prenom,$pays,$email,$adresse,$age,$id);

    }
    ?>
<div class="container">
    <form method="post" action="index.php?action=<?php echo ModifierClient ?>">
        <div class="row justify-content-between">
            <div class="col-md-5 container rounded" style="color:white; margin-left:25%; margin-top:4%; margin-bottom:4%; padding:2%; background:rgba(97, 97, 97, 0.329); ">
                <?php
$resultat=listClient();  
$ligne = $resultat->setFetchMode(PDO::FETCH_NUM);
$ligne = $resultat->fetch();
$html="";
?>
                <label for="ListeClientModifier">Les clients </label>
                <select name="ListeClientModifier" id="ListeClientModifier" class="form-control">
                    <?php
while ($ligne){
    $html.='<option value="'.$ligne[0].'">'.$ligne[1].'</option>';
    $ligne = $resultat->fetch();
}
echo $html;?>
                </select>
                <label for="NomClientModifier"> Nom du Client :</label>
                <input id="NomClientModifier" type='text' class="form-control" required name="NomClientModifier"
                    placeholder="Entrer l'identifiant"></input>
                <label for="PrenomClientModifier">Prenom du Client : </label>
                <input id="PrenomClientModifier" type='text' class="form-control" required name="PrenomClientModifier"
                    placeholder="Entrer l'identifiant"></input>
                <label for="AgeClientModifier">L'age du client : </label>
                <input id="AgeClientModifier" type='number' class="form-control " min=15 max=70 value="15"
                    name="AgeClientModifier"></input>
                <label for="EmailClientModifier"> Mail du client : </label>
                <input id="EmailClientModifier" type='text' class="form-control" required name="EmailClientModifier"
                    placeholder="Entrer l'identifiant"></input>
                <label for="PaysClientModifier"> Pays du Client : </label>
                <input id="PaysClientModifier" type='text' class="form-control" required name="PaysClientModifier"
                    placeholder="Entrer l'identifiant"></input>
                <label for="AdresseClientModifier">Adresse du Client : </label>
                <textarea id="AdresseClientModifier" name="AdresseClientModifier" class="form-control" rows="5"
                    required></textarea>

                <input type='submit' value='Modifier' class="btn btn-primary " style="margin-top:10px"
                    name='ClientModifier'>
                </input>
            </div>
        </div>
    </form>
</div>


<?php


    break;




case SupprimmerClient:
    if (isset($_POST['SupprimmerClient'])){
        $id=$_POST['idClient'];
        echo SupprimerClient($id);
    }
   ?>
<div class="container rounded">
    <form method="post" action="index.php?action=<?php echo SupprimmerClient ?>">
        <div class="row justify-content-between container rounded">
            <div class="col-md-5 container rounded" style="color:white; margin-left:25%; margin-top:4%; margin-bottom:4%; padding:2%; background:rgba(97, 97, 97, 0.329); ">
                <?php
$resultat=listClient();  
$ligne = $resultat->setFetchMode(PDO::FETCH_NUM);
$ligne = $resultat->fetch();
$html="";
?>
                <label for="idClient">Les clients </label>
                <select name="idClient" id="idClient" class="form-control">
                    <?php
while ($ligne){
    $html.='<option value="'.$ligne[0].'">'.$ligne[0].'</option>';
    $ligne = $resultat->fetch();
}
echo $html;?>
                </select>
                <input type='submit' value='Suprimmer' class="btn btn-primary " style="margin-top:10px"
                    name='SupprimmerClient'>
                </input>
            </div>
        </div>
    </form>
</div>
<?php
break;
case CommandesClient:

break;
}
?>
</body>

</html>