<?php
if (isset($_SESSION["TABLE"])){
  if($_SESSION["TABLE"]=="adherent"){ // gestion de l'affichage pour admin
    require_once './include/enteteAdmin.php';
  }
  else if ($_SESSION["TABLE"]=="clients") {  // gestion de l'affichage pour client
        require_once './include/enteteclient.php';
    }
}
else { // gestion de l'affichage pour les personnes deconnectées 
      require_once './include/entete.php';
    }
?>
<!-- video-->
<section id="video">
    <div class="section">

        <div class="video-container">
            <div class="color-overlay"></div>
            <div class="container">
                <div class="row justify-content-md-center">
                    <div class="col-md-10">
                        <img class="front" src="./img/logo.png" style=" margin-top:15%; width: 100%; max-width: 200px; height: auto; margin-left:35%;"
                            z-index="1"></img>
                    </div>
                </div>
            </div>
            <video autoplay loop muted style="border-bottom: 2px solid rgb(4 137 203) !important;">
                <source class="back" src="test3.mp4" type="video/mp4" z-index="-1">
            </video>
        </div>

    </div>
</section>
<!-- FIN video-->

<!-- Presentation-->
<section id="Presentation">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <p class="promo-title">Qui sommes Nous</p>
                <p style="color:#bac4d1">La Team Ryoken est une structure Esportive basée à monaco et axée sur la
                    compétition du jeu Fortnite
                    La Team Ryoken est une structure Esportive basée à monaco et axée sur la compétition du jeu Fortnite
                    La Team Ryoken est u²ne structure Esportive basée à monaco et axée sur la compétition du jeu
                    Fortnite
                    La Team Ryoken est une structure Esportive basée à monaco et axée sur la compétition du jeu Fortnite
                </p>
            </div>
            <div class="col-md-6 text-center">
                <img src="./img/ryoken_fond.png" class="img-fluid" />
            </div>
        </div>
    </div>
</section>
<!-- FIN Presentation-->

<?php

require_once './include/pied.php'
  ?>