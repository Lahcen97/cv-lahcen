<?php
if (isset($_SESSION["TABLE"])){
  if($_SESSION["TABLE"]=="adherent"){ // gestion de l'affichage pour admin
    require_once './include/enteteAdmin.php';
  }
  else if ($_SESSION["TABLE"]=="clients") {  // gestion de l'affichage pour client
        require_once './include/enteteclient.php';
    }
}
else {// gestion de l'affichage pour les personnes deconnectées 
      require_once './include/entete.php';
    }
?>
<?php
switch ($_REQUEST['action'])
    {
    case Shop:
if (isset($_POST["AjouterPanier"]) && isset($_SESSION['IDENTIFIANT'])){
    $article=$_POST['NomArticlePanier'];
    $client=$_SESSION['IDENTIFIANT'];
    $siArticleExisteDeja=articleDejaExistant($article,$client);
    if ($siArticleExisteDeja==0){
        $nombreArticle=$_POST['NombreArticlePanier'];
        echo AjouterPanier($article, $client,$nombreArticle);
    }
    else{
        echo '<script> alert("article existe déjà dans le panier.")</script>';
        }
    }
?>

<div id="shop" class="container-fluid " style="height:100%;">
    <div class="row" style="height:100%;">
        <div class="col-md-2 colVerticalNav">


            <h1> CATEGORIE </h1>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link disabled navbarVerticaleCategorie" href="#">
                        <h5> Vêtements </h5>
                    </a>
                </li>
                <?php
                echo GenererCategorie("vêtements");
                ?>
                <li class="nav-item">
                    <a class="nav-link disabled navbarVerticaleCategorie" href="#">
                        <h5> Accessoires </h5>
                    </a>
                </li>
                <?php
                echo GenererCategorie("accessoires");
                ?>
                <li class="nav-item">
                    <a class="nav-link navbarVerticaleCategorie CategoriClick" href="#">
                        <h5>Autres </h5>
                    </a>
                </li>

                <center>
                    <h5> Panier </h5>
                    <a href="index.php?action=<?php echo Panier?>"><svg xmlns="http://www.w3.org/2000/svg" width="70"
                            height="70" fill="currentColor" class="bi bi-cart4" viewBox="0 0 16 16">
                            <path
                                d="M0 2.5A.5.5 0 0 1 .5 2H2a.5.5 0 0 1 .485.379L2.89 4H14.5a.5.5 0 0 1 .485.621l-1.5 6A.5.5 0 0 1 13 11H4a.5.5 0 0 1-.485-.379L1.61 3H.5a.5.5 0 0 1-.5-.5zM3.14 5l.5 2H5V5H3.14zM6 5v2h2V5H6zm3 0v2h2V5H9zm3 0v2h1.36l.5-2H12zm1.11 3H12v2h.61l.5-2zM11 8H9v2h2V8zM8 8H6v2h2V8zM5 8H3.89l.5 2H5V8zm0 5a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0zm9-1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0z" />
                        </svg>
                    </a>
                </center>
            </ul>
        </div>
        <div class="col-md-10" style="background:#1a1e23; background-repeat: no-repeat;
  background-size: auto;">

            <div class="container-fluid appendCategorie" style="margin-top:15px;">
                <?php echo genererArticles (null); ?>
            </div>

        </div>
    </div>
</div>

<?php 
// <div class="col-md-6" id="colimg">
// 
// </div> <center id="logoonex"> <a target="_blank" rel="noopener noreferrer" class="colone-img"
//href="https://onexwear.co/">
//<img style="margin-bottom:20px; margin-top: 100PX;" src="./img/oneXwear_logo.png"
 //   class="part-img" />
//</a></center>
// <div class="col-md-6" id="colimg">
//   ?>
<?php
    break;
case PageArticleSelectione:
    if (isset($_SESSION["IDENTIFIANT"])){
        $value=$_SESSION["IDENTIFIANT"];
    }else {
        $value="null";
    }
    ?>
<div class="container-fluid " style="height:100%;">
    <div class="row" style="height:100%;">
        <div class="col-md-2 colVerticalNav">
            <h1> CATEGORIE </h1>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link disabled navbarVerticaleCategorie" href="#">
                        <h5> Vêtements </h5>
                    </a>
                </li>
                <?php
                echo GenererCategorie("vêtements");
                ?>
                <li class="nav-item">
                    <a class="nav-link disabled navbarVerticaleCategorie" href="#">
                        <h5> Accessoires </h5>
                    </a>
                </li>
                <?php
                echo GenererCategorie("accessoires");
                ?>
                <li class="nav-item">
                    <a class="nav-link navbarVerticaleCategorie CategoriClick" href="#">
                        <h5>Autres </h5>
                    </a>
                </li>

                <center>
                    <h5> Panier </h5>
                    <a href="index.php?action=<?php echo Panier?>"><svg xmlns="http://www.w3.org/2000/svg" width="70"
                            height="70" fill="currentColor" class="bi bi-cart4" viewBox="0 0 16 16">
                            <path
                                d="M0 2.5A.5.5 0 0 1 .5 2H2a.5.5 0 0 1 .485.379L2.89 4H14.5a.5.5 0 0 1 .485.621l-1.5 6A.5.5 0 0 1 13 11H4a.5.5 0 0 1-.485-.379L1.61 3H.5a.5.5 0 0 1-.5-.5zM3.14 5l.5 2H5V5H3.14zM6 5v2h2V5H6zm3 0v2h2V5H9zm3 0v2h1.36l.5-2H12zm1.11 3H12v2h.61l.5-2zM11 8H9v2h2V8zM8 8H6v2h2V8zM5 8H3.89l.5 2H5V8zm0 5a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0zm9-1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0z" />
                        </svg>
                    </a>
                </center>
            </ul>
        </div>
        <div class="col-md-10" style="background:#1a1e23; background-repeat: no-repeat;
  background-size: auto;">
            <div class="container-fluid appendCategorie" style="margin-top:15px;">
                <?php 
                $article=$_GET["article"];
                echo PageArticleSelectionne($article); ?>
                <form name="verifierConnexion">
                    <input type="hidden" id="connexion" name="connexion" value="<?php echo $value ?>">
                </form>
            </div>
        </div>
    </div>
</div>


<?php

    break;
    case Panier:
    if (isset($_SESSION["IDENTIFIANT"])){
        if (isset($_POST["SupprimerPanier"])){
                $IdClient=$_SESSION["IDENTIFIANT"];
                $nomArticles=$_POST["ArticlePanierSuprimmer"];
                echo SuprimmerPanier($IdClient, $nomArticles);

            
        }
    ?>
<div class="container-fluid " style="height:100%;">
    <div class="row" style="height:100%;">
        <div class="col-md-2 colVerticalNav">


            <h1> CATEGORIE </h1>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link disabled navbarVerticaleCategorie" href="#">
                        <h5> Vêtements </h5>
                    </a>
                </li>
                <?php
                echo GenererCategorie("vêtements");
                ?>
                <li class="nav-item">
                    <a class="nav-link disabled navbarVerticaleCategorie" href="#">
                        <h5> Accessoires </h5>
                    </a>
                </li>
                <?php
                echo GenererCategorie("accessoires");
                ?>
                <li class="nav-item">
                    <a class="nav-link navbarVerticaleCategorie CategoriClick" href="#">
                        <h5>Autres </h5>
                    </a>
                </li>

                <center>
                    <h5> Panier </h5>
                    <a href="index.php?action=<?php echo Panier?>"><svg xmlns="http://www.w3.org/2000/svg" width="70"
                            height="70" fill="currentColor" class="bi bi-cart4" viewBox="0 0 16 16">
                            <path
                                d="M0 2.5A.5.5 0 0 1 .5 2H2a.5.5 0 0 1 .485.379L2.89 4H14.5a.5.5 0 0 1 .485.621l-1.5 6A.5.5 0 0 1 13 11H4a.5.5 0 0 1-.485-.379L1.61 3H.5a.5.5 0 0 1-.5-.5zM3.14 5l.5 2H5V5H3.14zM6 5v2h2V5H6zm3 0v2h2V5H9zm3 0v2h1.36l.5-2H12zm1.11 3H12v2h.61l.5-2zM11 8H9v2h2V8zM8 8H6v2h2V8zM5 8H3.89l.5 2H5V8zm0 5a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0zm9-1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0z" />
                        </svg>
                    </a>
                </center>
            </ul>
        </div>
        <div class="col-md-10" style="background:#1a1e23; background-repeat: no-repeat;
  background-size: auto;">

            <div class="container-fluid appendCategorie" style="margin-top:15px;">
                <?php
                $id_client= $_SESSION["IDENTIFIANT"];
                echo PagePanierSelectionneRequete($id_client);
            ?>
                
                <div class="col-md-12 front rounded" style="margin-top:30%;  " id="formulaireLivraison" hidden>
                    <center>
                        <form method="post" action="index.php?action=<?php echo RecapitulatifCommande; ?> "
                            class="rounded ContenueSupprimerCategorie"
                            style="padding:40px 40px 40px 40px; width:60%; background:white;">
                            <label for="NomPrenomLivraison">Saisissez le nom et le prénom pour la livraison: </label>
                            <input id="NomPrenomLivraison" type='text' class="form-control" required
                                name="NomPrenomLivraison" placeholder="Entrer le nom"></input>
                            <label for="NumLivraison">Saisissez le numéro de telephone pour la livraison: :</label>
                            <input id="NumLivraison" type='text' class="form-control" required name="NumLivraison"
                                placeholder="Entrer le nom"></input>

                            <label for="AdresseLivraison">Saisissez l'adresse de livraison: </label>
                            <input id="AdresseLivraison" type='text' class="form-control " required
                                name="AdresseLivraison" placeholder="Entrer l'adresse de livraison'"></input>

                            <center> <input type='submit' value='Confirmer' class="btn btn-primary "
                                    style="margin-top:10px; margin-bottom:10px" name='ConfirmerLivraison'>
                                </input>
                            </center>
                        </form>
                    </center>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
    }
    else {
        ?>

<div class="container-fluid " style="height:100%;">
    <div class="row" style="height:100%;">
        <div class="col-md-2 colVerticalNav">
            <h1> CATEGORIE </h1>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link disabled navbarVerticaleCategorie" href="#">
                        <h5> Vêtements </h5>
                    </a>
                </li>
                <?php
                echo GenererCategorie("vêtements");
                ?>
                <li class="nav-item">
                    <a class="nav-link disabled navbarVerticaleCategorie" href="#">
                        <h5> Accessoires </h5>
                    </a>
                </li>
                <?php
                echo GenererCategorie("accessoires");
                ?>
                <li class="nav-item">
                    <a class="nav-link navbarVerticaleCategorie CategoriClick" href="#">
                        <h5>Autres </h5>
                    </a>
                </li>

                <center>
                    <h5> Panier </h5>
                    <a href="index.php?action=<?php echo Panier?>"><svg xmlns="http://www.w3.org/2000/svg" width="70"
                            height="70" fill="currentColor" class="bi bi-cart4" viewBox="0 0 16 16">
                            <path
                                d="M0 2.5A.5.5 0 0 1 .5 2H2a.5.5 0 0 1 .485.379L2.89 4H14.5a.5.5 0 0 1 .485.621l-1.5 6A.5.5 0 0 1 13 11H4a.5.5 0 0 1-.485-.379L1.61 3H.5a.5.5 0 0 1-.5-.5zM3.14 5l.5 2H5V5H3.14zM6 5v2h2V5H6zm3 0v2h2V5H9zm3 0v2h1.36l.5-2H12zm1.11 3H12v2h.61l.5-2zM11 8H9v2h2V8zM8 8H6v2h2V8zM5 8H3.89l.5 2H5V8zm0 5a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0zm9-1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0z" />
                        </svg>
                    </a>
                </center>
            </ul>
        </div>
        <div class="col-md-10" style="background:#1a1e23; background-repeat: no-repeat;
  background-size: auto;">
            <div class="container-fluid appendCategorie" style="margin-top:15px;">
                <div class="ContenueSupprimerCategorie">
                    <h1 style="margin-top:30px; margin-bottom:30px; color:rgb(4,137,203);"> Inscrivez-vous pour voir les articles dans le
                        panier. </h1>
                    
                    <form action="index.php?action=<?php echo confirmationMailInscription; ?>" method="post"
    onsubmit="return controleFrmInscription(this);" class="rounded" style="width:80%; color:white; background:rgba(97, 97, 97, 0.329); padding:20px; margin-bottom:20px;>
                        <label for="IdentifiantNouveauClt">Saisissez l'identifiant : </label>
                        <input id="IdentifiantNouveauClt" type='text' class="form-control" required
                            name="IdentifiantNouveauClt" placeholder="Entrez un identifiant"></input>

                        <label for="MdpNouveauClt">Saisissez un mot de passe : </label>
                        <input id="MdpNouveauClt" type='password' class="form-control" required name="MdpNouveauClt"
                            placeholder="Entrez un mot de passe"></input>

                        <label for="MdptestNouveauClt">Vérifiez le mot de passe : </label>
                        <input id="MdptestNouveauClt" type='password' class="form-control" required
                            name="MdptestNouveauClt" placeholder="Entrez une deuxieme fois le mot de passe"></input>

                        <label for="emailNouveauClt">Saisissez Votre mail : </label>
                        <input id="emailNouveauClt" type='email' class="form-control " required name="emailNouveauClt"
                            placeholder="Entrez un mail"></input>

                        <label for="NomNouveauClt">Saisissez votre nom : </label>
                        <input id="NomNouveauClt" type='text' class="form-control" required name="NomNouveauClt"
                            placeholder="Entrez un nom"></input>

                        <label for="PrenomNouveauClt">Saisissez votre prénom : </label>
                        <input id="PrenomNouveauClt" type='text' class="form-control " required name="PrenomNouveauClt"
                            placeholder="Entrez un prénom"></input>

                        <label for="PaysNouveauClt">Saisissez votre Pays : </label>
                        <input id="PaysNouveauClt" type='text' class="form-control " required name="PaysNouveauClt"
                            placeholder="Entrez un pays"></input>

                        <label for="AgeNouveauClt">Saisissez votre age : </label>
                        <input id="AgeNouveauClt" name="AgeNouveauClt" type='number' class="form-control"
                            placeholder="Entrez un age" min=15 max=70 value="15"></input>


                        <br>
                        <div class="g-recaptcha" data-sitekey="6LeQ6VQaAAAAAKopIiJ0bA0XfFBUpq79mWlCfDfo"></div>
                        <input type='submit' value='Créer un Compte' class="btn btn-primary " style="margin-top:10px"
                            name='inscrire'></input>
                      
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php
    }
    break;
?>

<?php
    case Facture:
        if (isset($_SESSION['IDENTIFIANT'])){
            if (isset($_POST["ConfirmerLivraison"])) {
                $nomprenom=$_POST["NomPrenomLivraison"];
                $numPortable=$_POST["NumLivraison"];
                $adresse=$_POST["AdresseLivraison"];
                $idClient=$_SESSION["IDENTIFIANT"];
                echo AjouterLivraison ($nomprenom,$adresse,$idClient,$numPortable);
            }
        }
        if (isset($_SESSION['IDENTIFIANT'])){
                $chaineAleatoire=genererChaineAleatoire(10);
                $id_client=$_SESSION["IDENTIFIANT"];
                               
            }
    ?>
<section id="facture" style="width: 45%;">
    <div class="top-facture">
        <img src="./img/logo.png" style="max-height:100px;margin-top:10px;margin-bottom:30px;"></img><br>
        <p id="facturetxt">N° Facture = <?php echo $chaineAleatoire ?> </p>
        <p id="facturetxt">Date de facturation = <?php
$date = new DateTime();
echo $date = date('d/m/Y');
?> </p>
        <p id="facturetxt"> <?php echo $nomprenom ?> </p>
        <p id="facturetxt"><?php echo $adresse ?></p>
        <p id="facturetxt">13400 Aubagne</p>
    </div>
    <div class="articles">
        <table style="border-collapse: separate; border-spacing: 13px 15px;">
            <thead>
                <tr>
                    <th scope="col">Articles</th>
                    <th id="nom-col" scope="col">Quantitée</th>
                    <th id="nom-col" scope="col">Prix unitaire</th>
                    <th id="nom-col" scope="col">Prix Total Par articles</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $id_client=$_SESSION["IDENTIFIANT"];
                    echo FactureArticles($id_client);
                ?>
            </tbody>
            <tfoot>
                <tr>
                    <th scope="row" colspan="3">Prix Total</th>
                    <?php echo PrixTotalCommande($idClient)?>
                </tr>
            </tfoot>
        </table>
    </div>
</section>
<?php
    break;
    case RecapitulatifCommande:
        if (isset($_SESSION['IDENTIFIANT'])){
            if (isset($_POST["ConfirmerLivraison"])) {
                $nomprenom=$_POST["NomPrenomLivraison"];
                $numPortable=$_POST["NumLivraison"];
                $adresse=$_POST["AdresseLivraison"];
                $idClient=$_SESSION["IDENTIFIANT"];
            }
    }
    ?>
<section id="facture" style="width: 45%;">
    <div class="top-facture">
        <img src="./img/logo.png" style="max-height:100px;margin-top:10px;margin-bottom:30px;"></img><br>
        <p id="facturetxt">Date de facturation = <?php
$date = new DateTime();
echo $date = date('d/m/Y');
?> </p>
        <p id="facturetxt"> <?php echo $nomprenom ?> </p>
        <p id="facturetxt"><?php echo $adresse ?></p>
        <p id="facturetxt">13400 Aubagne</p>
    </div>
    <div class="articles">
        <table style="border-collapse: separate; border-spacing: 13px 15px;">
            <thead>
                <tr>
                    <th scope="col">Articles</th>
                    <th id="nom-col" scope="col">Quantitée</th>
                    <th id="nom-col" scope="col">Prix unitaire</th>
                    <th id="nom-col" scope="col">Prix Total Par articles</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $id_client=$_SESSION["IDENTIFIANT"];
                    echo FactureArticles($id_client);
                ?>
            </tbody>
            <tfoot>
                <tr>
                    <th scope="row" colspan="3">Prix Total</th>
                    <?php echo PrixTotalCommande($idClient)?>
                </tr>
            </tfoot>
        </table>
        <input type='submit' value='Payer' class="btn btn-primary" style="margin-top:10px" name="submitArticle">
    </div>
</section>

<?php
    break;
}
?>